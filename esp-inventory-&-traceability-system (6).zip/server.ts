import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { BlobServiceClient } from '@azure/storage-blob';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Azure Storage Configuration
const AZURE_CONNECTION_STRING = process.env.AZURE_STORAGE_CONNECTION_STRING;
const CONTAINER_NAME = process.env.AZURE_STORAGE_CONTAINER_NAME || 'inventory-data';
const BLOB_NAME = process.env.AZURE_MOTHER_FILE_NAME || 'archivo_madre.xlsx';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // Request logger
  app.use((req, res, next) => {
    console.log(`[Server] ${req.method} ${req.url}`);
    next();
  });

  // Azure Blob Storage Endpoints
  app.get('/api/azure/mother-file', async (req, res) => {
    if (!AZURE_CONNECTION_STRING) {
      return res.status(500).json({ error: 'AZURE_STORAGE_CONNECTION_STRING is not configured' });
    }

    try {
      const blobServiceClient = BlobServiceClient.fromConnectionString(AZURE_CONNECTION_STRING);
      const containerClient = blobServiceClient.getContainerClient(CONTAINER_NAME);
      const blobClient = containerClient.getBlobClient(BLOB_NAME);

      const exists = await blobClient.exists();
      if (!exists) {
        return res.status(404).json({ error: 'Mother file not found in Azure' });
      }

      const downloadResponse = await blobClient.download();
      const buffer = await streamToBuffer(downloadResponse.readableStreamBody!);
      
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename=${BLOB_NAME}`);
      res.send(buffer);
    } catch (error: any) {
      console.error('[Azure] Error downloading file:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/azure/mother-file', async (req, res) => {
    if (!AZURE_CONNECTION_STRING) {
      return res.status(500).json({ error: 'AZURE_STORAGE_CONNECTION_STRING is not configured' });
    }

    const { fileBase64 } = req.body;
    if (!fileBase64) {
      return res.status(400).json({ error: 'No file data provided' });
    }

    try {
      const blobServiceClient = BlobServiceClient.fromConnectionString(AZURE_CONNECTION_STRING);
      const containerClient = blobServiceClient.getContainerClient(CONTAINER_NAME);
      
      // Ensure container exists
      await containerClient.createIfNotExists();
      
      const blockBlobClient = containerClient.getBlockBlobClient(BLOB_NAME);
      const buffer = Buffer.from(fileBase64, 'base64');

      await blockBlobClient.uploadData(buffer);
      res.json({ success: true, message: 'Mother file updated successfully' });
    } catch (error: any) {
      console.error('[Azure] Error uploading file:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Helper function to convert stream to buffer
  async function streamToBuffer(readableStream: NodeJS.ReadableStream): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      const chunks: Buffer[] = [];
      readableStream.on('data', (data) => {
        chunks.push(data instanceof Buffer ? data : Buffer.from(data));
      });
      readableStream.on('end', () => {
        resolve(Buffer.concat(chunks));
      });
      readableStream.on('error', reject);
    });
  }

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'Server is running' });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
