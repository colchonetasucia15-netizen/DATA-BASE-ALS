import { ESPRecord } from '../types';
import * as XLSX from 'xlsx';
import { mapExcelRowsToRecords } from '../utils/excelMapper';

export const azureService = {
  /**
   * Downloads the mother file from Azure and parses it into ESPRecord[]
   */
  async downloadMotherFile(): Promise<ESPRecord[]> {
    const response = await fetch('/api/azure/mother-file');
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to download mother file from Azure');
    }

    const blob = await response.blob();
    const arrayBuffer = await blob.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

    return mapExcelRowsToRecords(jsonData as any[][]);
  },

  /**
   * Converts records to Excel and uploads to Azure
   */
  async uploadMotherFile(records: ESPRecord[]): Promise<void> {
    // Convert records to a flat format for Excel
    const flatData = records.map(r => ({
      Pozo: r.pozo,
      Nick: r.nick,
      Activo: r.activo,
      Bloque: r.bloque,
      Campo: r.campo,
      Cluster: r.cluster,
      Proveedor: r.proveedor,
      Estado: r.estadoInventario,
      'Run Life': r.runLife,
      'Fecha Run': r.fechaRun,
      'Fecha Falla': r.fechaFalla,
      'Fecha Pulling': r.fechaPull,
      // Add more fields as needed based on your "archivo madre" structure
    }));

    const worksheet = XLSX.utils.json_to_sheet(flatData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Inventario');

    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const base64 = btoa(
      new Uint8Array(excelBuffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
    );

    const response = await fetch('/api/azure/mother-file', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ fileBase64: base64 }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to upload mother file to Azure');
    }
  }
};
