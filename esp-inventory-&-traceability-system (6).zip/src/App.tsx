/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as React from 'react';
import { DashboardCards } from './components/DashboardCards';
import { InventoryList } from './components/InventoryList';
import { ESPForm } from './components/ESPForm';
import { ExcelImport } from './components/ExcelImport';
import { Movements } from './components/Movements';
import { EquipmentTracker } from './components/EquipmentTracker';
import { ESPRecord, DashboardStats, EquipmentComponent } from './types';
import { mapExcelRowsToRecords } from './utils/excelMapper';
import { azureService } from './services/azureService';
import {
  Database, Plus, List, LayoutDashboard, Search, X, Copy, Check, AlertCircle, AlertTriangle, Grid, Table, Anchor, Box, Upload, FileSpreadsheet, Trash2, ArrowRightLeft, History, Download, RefreshCw, Settings, Zap, Cloud
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import * as idb from 'idb-keyval';
import firebaseConfig from '../firebase-applet-config.json';
import {
  db, collection, onSnapshot, query, orderBy, setDoc, deleteDoc, doc, updateDoc, serverTimestamp, OperationType, handleFirestoreError, writeBatch, onQuotaExceeded,
  loginWithGoogle, logout, onAuthChange, User
} from './firebase';

// Error Boundary Component
interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public state: ErrorBoundaryState;
  public props: ErrorBoundaryProps;

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
    this.props = props;
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("ErrorBoundary caught an error", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      let displayMessage = "Ha ocurrido un error inesperado.";
      let isQuotaError = false;

      try {
        const errorMsg = this.state.error?.message || "";
        if (errorMsg.includes("resource-exhausted") || errorMsg.includes("Quota limit exceeded")) {
          isQuotaError = true;
          const isReadQuota = errorMsg.includes("read units");
          displayMessage = isReadQuota 
            ? "Límite de lectura diaria de Firebase excedido (50,000 lecturas). El sistema está funcionando en modo lectura desde caché local."
            : "Límite de escritura diaria de Firebase excedido (20,000 escrituras). El sistema se restablecerá automáticamente mañana.";
        } else {
          const parsed = JSON.parse(errorMsg);
          if (parsed.error) {
            if (parsed.error.includes("insufficient permissions")) {
              displayMessage = "No tienes permisos suficientes para realizar esta operación.";
            } else if (parsed.error.includes("resource-exhausted") || parsed.error.includes("Quota limit exceeded")) {
              isQuotaError = true;
              const isReadQuota = parsed.error.includes("read units");
              displayMessage = isReadQuota
                ? "Límite de lectura diaria de Firebase excedido (50,000 lecturas). El sistema está funcionando en modo lectura desde caché local."
                : "Límite de escritura diaria de Firebase excedido (20,000 escrituras). El sistema se restablecerá automáticamente mañana.";
            }
          }
        }
      } catch (e) {
        // Not a JSON error
      }

      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
          <div className="bg-white p-8 rounded-3xl shadow-xl max-w-md w-full text-center border border-rose-100">
            <div className="bg-rose-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <AlertCircle className="w-8 h-8 text-rose-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              {isQuotaError ? "Cuota Excedida" : "¡Ups! Algo salió mal"}
            </h2>
            <p className="text-gray-500 mb-8 leading-relaxed">{displayMessage}</p>
            <button
              onClick={() => window.location.reload()}
              className="w-full py-3 bg-gray-900 text-white font-bold rounded-xl hover:bg-gray-800 transition-all shadow-lg"
            >
              Reintentar / Recargar
            </button>
            {isQuotaError && (
              <p className="mt-4 text-[10px] text-gray-400 uppercase tracking-widest font-bold">
                Nota: La capa gratuita de Firebase permite 20,000 escrituras al día.
              </p>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function AppContent() {
  const [user, setUser] = React.useState<User | null>(null);
  const [authLoading, setAuthLoading] = React.useState(true);
  const [records, setRecords] = React.useState<ESPRecord[]>([]);
  const [view, setView] = React.useState<'dashboard' | 'form' | 'list' | 'movements' | 'equipment'>('dashboard');
  const [loading, setLoading] = React.useState(false);
  const [selectedRecord, setSelectedRecord] = React.useState<ESPRecord | null>(null);
  const [inventoryView, setInventoryView] = React.useState<'table'>('table');
  const [categoryFilter, setCategoryFilter] = React.useState<string | null>(null);
  const [showImport, setShowImport] = React.useState(false);
  const [showClearConfirm, setShowClearConfirm] = React.useState(false);
  const [showIndividualDeleteConfirm, setShowIndividualDeleteConfirm] = React.useState(false);
  const [isClearing, setIsClearing] = React.useState(false);
  const [isSyncingAzure, setIsSyncingAzure] = React.useState(false);
  const [importProgress, setImportProgress] = React.useState<{ current: number, total: number } | null>(null);
  const [dailyWrites, setDailyWrites] = React.useState(0);
  const [pauseSnapshot, setPauseSnapshot] = React.useState(false);
  const [isReadQuotaExceeded, setIsReadQuotaExceeded] = React.useState(false);
  const [connectionStatus, setConnectionStatus] = React.useState<'connecting' | 'connected' | 'error' | 'offline'>('connecting');
  const [lastError, setLastError] = React.useState<string | null>(null);
  const [serverHealth, setServerHealth] = React.useState<{ status: string; message: string } | null>(null);

  React.useEffect(() => {
    const unsubscribe = onAuthChange((u) => {
      setUser(u);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await loginWithGoogle();
    } catch (error: any) {
      console.error('Login error:', error);
      if (error.code === 'auth/unauthorized-domain') {
        setLastError("Error de dominio no autorizado. Por favor, añade los dominios de Cloud Run a la lista de dominios autorizados en la consola de Firebase (Autenticación -> Ajustes).");
      } else {
        setLastError(`Error de inicio de sesión: ${error.message}`);
      }
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      setRecords([]);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const checkServerHealth = async () => {
    try {
      const res = await fetch('/api/health');
      if (res.ok) {
        const data = await res.json();
        setServerHealth(data);
      } else {
        setServerHealth({ status: 'error', message: `HTTP ${res.status}` });
      }
    } catch (e: any) {
      setServerHealth({ status: 'error', message: e.message });
    }
  };

  React.useEffect(() => {
    checkServerHealth();
    const interval = setInterval(checkServerHealth, 30000);
    return () => clearInterval(interval);
  }, []);

  const forceReload = async () => {
    setPauseSnapshot(true);
    setRecords([]);
    setLastError(null);
    setConnectionStatus('connecting');
    try {
      // Clear all possible caches
      await idb.clear();
      localStorage.removeItem('esp_records_cache');
      localStorage.removeItem('last_sync_time');
      // We keep settings like URLs but clear data
      console.log('[System] Cache cleared successfully');
    } catch (e) {
      console.error('[System] Error clearing cache:', e);
    }
    // Small delay to ensure state updates and then reconnect
    setTimeout(() => setPauseSnapshot(false), 800);
  };

  const WRITE_LIMIT = 20000;
  const isQuotaExceeded = dailyWrites >= WRITE_LIMIT;

  // Track estimated writes locally
  React.useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const stored = localStorage.getItem(`esp_writes_${today}`);
    if (stored) setDailyWrites(parseInt(stored, 10));

    // Listen for server-side quota errors
    const unsubscribe = onQuotaExceeded(() => {
      setDailyWrites(WRITE_LIMIT);
      localStorage.setItem(`esp_writes_${today}`, WRITE_LIMIT.toString());
    });

    return () => unsubscribe();
  }, []);

  const trackWrites = (count: number) => {
    const today = new Date().toISOString().split('T')[0];
    const newTotal = dailyWrites + count;
    setDailyWrites(newTotal);
    localStorage.setItem(`esp_writes_${today}`, newTotal.toString());
  };

  const resetQuotaCounter = () => {
    const today = new Date().toISOString().split('T')[0];
    setDailyWrites(0);
    localStorage.removeItem(`esp_writes_${today}`);
    alert('Contador de cuota reiniciado localmente. Nota: Esto no reinicia la cuota en los servidores de Firebase.');
  };

  const handleAzureSync = async () => {
    if (isSyncingAzure) return;
    
    setIsSyncingAzure(true);
    try {
      // 1. Download and parse mother file from Azure
      const azureRecords = await azureService.downloadMotherFile();
      
      if (azureRecords.length === 0) {
        alert('El archivo madre en Azure está vacío.');
        return;
      }

      // 2. Confirm with user
      if (!confirm(`Se han encontrado ${azureRecords.length} registros en Azure. ¿Desea sincronizarlos con la base de datos actual? Se sobrescribirán los datos existentes.`)) {
        return;
      }

      // 3. Batch update Firestore
      const batch = writeBatch(db);
      let count = 0;
      
      // For simplicity, we'll clear and re-upload if it's a full sync
      // or we could merge by Pozo name. Let's merge by Pozo.
      for (const record of azureRecords) {
        if (isQuotaExceeded) break;
        
        const existing = records.find(r => r.pozo === record.pozo);
        const recordRef = existing?.id ? doc(db, 'esp_records', existing.id) : doc(collection(db, 'esp_records'));
        
        batch.set(recordRef, {
          ...record,
          uid: user?.uid || 'public_user',
          updatedAt: serverTimestamp()
        });
        count++;
        
        if (count >= 400) { // Firestore batch limit is 500
          await batch.commit();
          count = 0;
        }
      }
      
      if (count > 0) {
        await batch.commit();
      }

      alert('Sincronización con Azure completada con éxito.');
    } catch (error: any) {
      console.error('[Azure Sync] Error:', error);
      alert(`Error al sincronizar con Azure: ${error.message}`);
    } finally {
      setIsSyncingAzure(false);
    }
  };

  const handleExportToExcel = (data: ESPRecord[] = records) => {
    if (data.length === 0) {
      alert('No hay datos para exportar.');
      return;
    }

    // Simple CSV export as a fallback for "Excel"
    const headers = ['Pozo', 'Nick', 'Activo', 'Bloque', 'Campo', 'Cluster', 'Proveedor', 'Estado', 'Run Life'];
    const csvContent = [
      headers.join(','),
      ...data.map(r => [
        r.pozo,
        r.nick,
        r.activo,
        r.bloque,
        r.campo,
        r.cluster,
        r.proveedor,
        r.estadoInventario,
        r.runLife
      ].map(v => `"${v || ''}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `ESP_Master_Export_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  React.useEffect(() => {
    if (pauseSnapshot || !user) {
      if (!user) setConnectionStatus('offline');
      return;
    }

    // Load from cache initially if available
    const loadCache = async () => {
      try {
        const cached = await idb.get('esp_records_cache');
        if (cached && Array.isArray(cached) && cached.length > 0) {
          console.log(`[Cache] Loaded ${cached.length} records from IndexedDB`);
          setRecords(cached);
        } else {
          // Fallback to localStorage if IndexedDB is empty (migration)
          const oldCached = localStorage.getItem('esp_records_cache');
          if (oldCached) {
            const parsed = JSON.parse(oldCached);
            if (Array.isArray(parsed) && parsed.length > 0) {
              console.log(`[Cache] Migrating ${parsed.length} records from localStorage to IndexedDB`);
              setRecords(parsed);
              await idb.set('esp_records_cache', parsed);
              localStorage.removeItem('esp_records_cache');
            }
          }
        }
      } catch (e) {
        console.error('[Cache] Error loading cached records:', e);
      }
    };

    loadCache();

    if (pauseSnapshot) {
      setConnectionStatus('offline');
      return;
    }

    setConnectionStatus('connecting');
    const q = query(collection(db, 'esp_records'));
    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ESPRecord));
      
      // Sort in memory to avoid issues with missing timestamp fields in Firestore query
      data.sort((a, b) => {
        const timeA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
        const timeB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
        return timeB - timeA;
      });

      console.log(`[Firestore] Received ${data.length} records from snapshot`);
      setRecords(data);
      setIsReadQuotaExceeded(false);
      setConnectionStatus('connected');
      setLastError(null);
      // Save to cache (IndexedDB handles large data better than localStorage)
      try {
        await idb.set('esp_records_cache', data);
      } catch (e) {
        console.error('[Cache] Error saving to IndexedDB:', e);
      }
    }, async (error) => {
      const errorMsg = error instanceof Error ? error.message : String(error);
      const isQuotaError = errorMsg.includes("resource-exhausted") || 
                           errorMsg.includes("Quota limit exceeded") ||
                           errorMsg.includes("quota-exceeded");
      
      const isConfigError = errorMsg.includes("permission-denied") || 
                            errorMsg.includes("unauthenticated") ||
                            errorMsg.includes("not-found");

      setConnectionStatus('error');
      
      let displayError = errorMsg;
      if (isConfigError) {
        displayError = "Error de permisos o configuración. Si has remezclado esta app, es posible que necesites re-vincular Firebase desde los Ajustes.";
      } else if (isQuotaError) {
        displayError = "Límite de lectura de Firebase excedido. Usando datos en caché.";
      }

      setLastError(displayError);

      // Check for read quota exhaustion
      if (isQuotaError) {
        setIsReadQuotaExceeded(true);
        try {
          const cached = await idb.get('esp_records_cache');
          if (cached && Array.isArray(cached)) {
            setRecords(cached);
            return;
          }
        } catch (e) {}
      }

      if (!pauseSnapshot) {
        handleFirestoreError(error, OperationType.LIST, 'esp_records', false);
      }
    });

    return () => unsubscribe();
  }, [pauseSnapshot, user]);

  const stats: DashboardStats = React.useMemo(() => {
    const s: DashboardStats = {
      totalRecords: records.length,
      totalOperativos: 0,
      totalFallados: 0,
      totalPulling: 0,
      avgRunLife: 0,
      healthScore: 0,
      mtbf: 0,
      totalPendingPostPull: 0,
      statusDistribution: [],
      providerDistribution: [],
      campoDistribution: [],
      kvaDistribution: [],
      hpDistribution: [],
      failureByProvider: [],
      topWells: [],
      recentFailures: [],
      avgRunLifeByProvider: [],
      statusByCampo: [],
      runLifeDistribution: [],
      equipmentCondition: {
        fondo: { new: 0, used: 0, rep: 0 },
        cable: { new: 0, used: 0, rep: 0 },
      },
    };

    if (records.length === 0) return s;

    const providers: Record<string, number> = {};
    const providerRunLife: Record<string, { total: number; count: number }> = {};
    const failureProviders: Record<string, number> = {};
    const campos: Record<string, { operativo: number; fallado: number; pulling: number }> = {};
    const kvas: Record<string, number> = {};
    const hps: Record<string, number> = {};
    const runLifeRanges: Record<string, number> = {
      '0-100': 0,
      '101-300': 0,
      '301-600': 0,
      '601-1000': 0,
      '1000+': 0
    };
    let totalRunLife = 0;
    let failedRunLife = 0;
    let failedCount = 0;

    records.forEach(r => {
      // Basic counts
      if (r.estadoInventario === 'PULLING') s.totalPulling++;
      else if (r.estadoInventario === 'FALLADO') {
        s.totalFallados++;
        failedCount++;
        failedRunLife += r.runLife || 0;
        failureProviders[r.proveedor] = (failureProviders[r.proveedor] || 0) + 1;
      } else {
        s.totalOperativos++;
      }

      // Run Life statistics: Only for wells that failed or were pulled (extracted)
      if (r.estadoInventario === 'FALLADO' || r.estadoInventario === 'PULLING') {
        totalRunLife += r.runLife || 0;

        // Run Life Distribution (only extracted)
        const rl = r.runLife || 0;
        if (rl <= 100) runLifeRanges['0-100']++;
        else if (rl <= 300) runLifeRanges['101-300']++;
        else if (rl <= 600) runLifeRanges['301-600']++;
        else if (rl <= 1000) runLifeRanges['601-1000']++;
        else runLifeRanges['1000+']++;

        if (!providerRunLife[r.proveedor]) providerRunLife[r.proveedor] = { total: 0, count: 0 };
        providerRunLife[r.proveedor].total += r.runLife || 0;
        providerRunLife[r.proveedor].count += 1;
      }

      // Distributions
      providers[r.proveedor] = (providers[r.proveedor] || 0) + 1;

      if (!campos[r.campo]) campos[r.campo] = { operativo: 0, fallado: 0, pulling: 0 };
      if (r.estadoInventario === 'PULLING') campos[r.campo].pulling++;
      else if (r.estadoInventario === 'FALLADO') campos[r.campo].fallado++;
      else campos[r.campo].operativo++;

      const kva = r.superficie?.vsd?.kva || 'N/A';
      if (kva !== 'N/A' && kva !== '') {
        kvas[kva] = (kvas[kva] || 0) + 1;
      }

      const hp = r.fondo?.motorUT?.hp || 'N/A';
      if (hp !== 'N/A' && hp !== '') {
        hps[hp] = (hps[hp] || 0) + 1;
      }

      // Condition (Only Fondo and Cable as per user request)
      const checkCond = (comp: any, cat: 'fondo' | 'cable') => {
        if (comp?.estado === 'NEW') s.equipmentCondition[cat].new++;
        else if (comp?.estado === 'USED') s.equipmentCondition[cat].used++;
        else if (comp?.estado === 'REP') s.equipmentCondition[cat].rep++;
      };

      checkCond(r.fondo?.motorUT, 'fondo');
      checkCond(r.cable?.cableFondo, 'cable');

      // Check for pending post-pulling classification
      const isPending = (comp: any) => comp?.estadoPostPull === 'PENDIENTE';
      if (
        isPending(r.fondo?.pumpLower) ||
        isPending(r.fondo?.intakeSeparador) ||
        isPending(r.fondo?.protectorSuperior) ||
        isPending(r.fondo?.motorUT) ||
        isPending(r.fondo?.sensor) ||
        isPending(r.cable?.cableFondo) ||
        isPending(r.superficie?.vsd)
      ) {
        s.totalPendingPostPull++;
      }
    });

    s.avgRunLife = (s.totalFallados + s.totalPulling) > 0
      ? Math.round(totalRunLife / (s.totalFallados + s.totalPulling))
      : 0;
    s.mtbf = failedCount > 0 ? Math.round(failedRunLife / failedCount) : 0;

    // Health Score: Operativos vs Fallados (ignoring pulling for health ratio)
    const activeTotal = s.totalOperativos + s.totalFallados;
    s.healthScore = activeTotal > 0 ? Math.round((s.totalOperativos / activeTotal) * 100) : 0;

    s.statusDistribution = [
      { name: 'Operativo', value: s.totalOperativos, color: '#10b981' },
      { name: 'Fallado', value: s.totalFallados, color: '#ef4444' },
      { name: 'Pulling', value: s.totalPulling, color: '#f59e0b' },
    ];

    s.providerDistribution = Object.entries(providers).map(([name, value]) => ({ name, value }));
    s.failureByProvider = Object.entries(failureProviders).map(([name, value]) => ({ name, value }));
    s.avgRunLifeByProvider = Object.entries(providerRunLife).map(([name, data]) => ({
      name,
      value: Math.round(data.total / data.count)
    }));
    s.statusByCampo = Object.entries(campos).map(([campo, data]) => ({
      campo,
      ...data
    }));

    s.campoDistribution = Object.entries(campos).map(([name, data]) => ({
      name,
      value: data.operativo + data.fallado + data.pulling
    }));

    s.kvaDistribution = Object.entries(kvas).map(([name, value]) => ({ name, value }));
    s.hpDistribution = Object.entries(hps).map(([name, value]) => ({ name, value }));
    s.runLifeDistribution = Object.entries(runLifeRanges).map(([range, count]) => ({ range, count }));

    s.topWells = [...records]
      .sort((a, b) => (b.runLife || 0) - (a.runLife || 0))
      .slice(0, 5)
      .map(r => ({ pozo: r.pozo, runLife: r.runLife, provider: r.proveedor }));

    s.recentFailures = [...records]
      .filter(r => r.estadoInventario === 'FALLADO')
      .sort((a, b) => (a.runLife || 0) - (b.runLife || 0)) // Shortest run life failures first
      .slice(0, 5)
      .map(r => ({ pozo: r.pozo, runLife: r.runLife, provider: r.proveedor }));

    return s;
  }, [records]);

  const cleanObject = (obj: any): any => {
    const newObj: any = Array.isArray(obj) ? [] : {};
    Object.keys(obj).forEach(key => {
      if (obj[key] === undefined) return;
      if (obj[key] !== null && typeof obj[key] === 'object') {
        newObj[key] = cleanObject(obj[key]);
      } else {
        newObj[key] = obj[key];
      }
    });
    return newObj;
  };

  const handleClearDatabase = async () => {
    if (records.length === 0) return;

    setIsClearing(true);
    setPauseSnapshot(true);
    try {
      // Use smaller batches to avoid saturating the write stream
      const batchSize = 25;
      for (let i = 0; i < records.length; i += batchSize) {
        const batch = writeBatch(db);
        const chunk = records.slice(i, i + batchSize);

        chunk.forEach(r => {
          if (r.id) {
            batch.delete(doc(db, 'esp_records', r.id));
          }
        });

        await batch.commit();
        trackWrites(chunk.length);

        // Aumentamos la pausa para evitar saturar el flujo
        if (i + batchSize < records.length) {
          await new Promise(resolve => setTimeout(resolve, 1500));
        }
      }

      setShowClearConfirm(false);
      setView('dashboard');
    } catch (error) {
      console.error("Error clearing database:", error);
      handleFirestoreError(error, OperationType.DELETE, 'esp_records');
    } finally {
      setIsClearing(false);
      setPauseSnapshot(false);
    }
  };

  const handleDeleteRecord = async (id: string) => {
    if (!id) return;
    if (isQuotaExceeded) {
      alert('Límite de cuota diaria alcanzado. No se puede eliminar el registro.');
      return;
    }
    try {
      const record = records.find(r => r.id === id);
      await deleteDoc(doc(db, 'esp_records', id));
      trackWrites(1);
      if (record) {
        // syncWithPowerAutomate was removed
      }
      setSelectedRecord(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `esp_records/${id}`);
    }
  };

  const handleAddRecord = async (record: ESPRecord) => {
    if (isQuotaExceeded) {
      alert('Límite de cuota diaria alcanzado. No se puede crear el registro.');
      return;
    }
    const id = Math.random().toString(36).substr(2, 9);
    const newRecord = cleanObject({
      ...record,
      id,
      uid: user?.uid || 'public_user',
      timestamp: new Date().toISOString()
    });

    try {
      await setDoc(doc(db, 'esp_records', id), newRecord);
      trackWrites(1);
      setView('dashboard');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `esp_records/${id}`);
    }
  };

  const handleBulkImport = async (newRecords: ESPRecord[]) => {
    if (isQuotaExceeded) {
      alert('Límite de cuota diaria de Firebase alcanzado. No se pueden importar más registros hoy.');
      return;
    }

    if (dailyWrites + newRecords.length > WRITE_LIMIT) {
      const proceed = window.confirm(`Esta importación (${newRecords.length} registros) podría exceder tu cuota diaria restante (${WRITE_LIMIT - dailyWrites} disponibles). ¿Deseas intentar continuar?`);
      if (!proceed) return;
    }

    setImportProgress({ current: 0, total: newRecords.length });
    setPauseSnapshot(true);
    let uploadedCount = 0;
    let skippedCount = 0;

    try {
      // Create a map of existing records for quick lookup
      const existingMap = new Map<string, ESPRecord>();
      records.forEach(r => {
        if (r.id) existingMap.set(r.id, r);
      });

      // Filter only records that have changed or are new
      const recordsToProcess = newRecords.map(record => {
        const safePozo = (record.pozo || 'unknown').toLowerCase().replace(/[^a-z0-9]/g, '_');
        const safeNick = (record.nick || '').toLowerCase().replace(/[^a-z0-9]/g, '_');
        const id = `esp_${safePozo}${safeNick ? '_' + safeNick : ''}`;
        
        const existing = existingMap.get(id);
        const recordWithAuth = cleanObject({
          ...record,
          id,
          uid: user?.uid || 'public_user',
          timestamp: record.timestamp || new Date().toISOString(),
          runLife: isNaN(Number(record.runLife)) ? 0 : Number(record.runLife)
        });

        if (existing) {
          // Compare relevant fields to see if update is needed
          const hasChanged = 
            existing.pozo !== record.pozo ||
            existing.nick !== record.nick ||
            existing.activo !== record.activo ||
            existing.estadoInventario !== record.estadoInventario ||
            existing.runLife !== record.runLife ||
            existing.proveedor !== record.proveedor ||
            existing.campo !== record.campo ||
            existing.bloque !== record.bloque ||
            existing.cluster !== record.cluster ||
            JSON.stringify(existing.fondo) !== JSON.stringify(record.fondo) ||
            JSON.stringify(existing.cable) !== JSON.stringify(record.cable) ||
            JSON.stringify(existing.superficie) !== JSON.stringify(record.superficie);

          return hasChanged ? recordWithAuth : null;
        }
        return recordWithAuth;
      }).filter(r => r !== null) as ESPRecord[];

      skippedCount = newRecords.length - recordsToProcess.length;
      console.log(`[Import] Analysis: ${recordsToProcess.length} to update/create, ${skippedCount} skipped (no changes)`);

      if (recordsToProcess.length === 0) {
        alert(`Importación finalizada: Todos los registros (${newRecords.length}) ya están actualizados. Se ahorraron ${newRecords.length} escrituras.`);
        return;
      }

      const batchSize = 25;
      for (let i = 0; i < recordsToProcess.length; i += batchSize) {
        const batch = writeBatch(db);
        const chunk = recordsToProcess.slice(i, i + batchSize);

        chunk.forEach(record => {
          if (record.id) {
            batch.set(doc(db, 'esp_records', record.id), record);
          }
        });

        await batch.commit();
        trackWrites(chunk.length);
        uploadedCount += chunk.length;
        setImportProgress({ current: uploadedCount, total: recordsToProcess.length });

        // Aumentamos la pausa para evitar saturar el flujo
        if (i + batchSize < recordsToProcess.length) {
          await new Promise(resolve => setTimeout(resolve, 1500));
        }
      }

      setView('dashboard');
      alert(`¡Importación exitosa! Se subieron ${uploadedCount} registros. Se omitieron ${skippedCount} sin cambios.`);
    } catch (error: any) {
      console.error("Bulk import error:", error);

      let errorMessage = "Error al importar registros.";
      if (error?.message?.includes("resource-exhausted") || error?.code === "resource-exhausted") {
        errorMessage = `Límite de cuota diaria excedido o flujo de escritura saturado. Se lograron subir ${uploadedCount} de ${newRecords.length} registros.`;
      }

      alert(errorMessage);
      if (uploadedCount === 0) {
        handleFirestoreError(error, OperationType.CREATE, 'esp_records');
      }
    } finally {
      setImportProgress(null);
      setPauseSnapshot(false);
    }
  };

  const handleStatusUpdate = async (
    recordId: string,
    newStatus: 'FALLADO' | 'PULLING' | 'OPERATIVO',
    pullingData?: { razonPulling: string; razonEspecificaPulling: string; fecha?: string; componentStatuses?: Record<string, string> },
    fallaData?: { fecha?: string }
  ) => {
    if (isQuotaExceeded) {
      alert('Límite de cuota diaria de Firebase alcanzado (20,000 escrituras). No se pueden realizar más actualizaciones hasta mañana.');
      return;
    }
    try {
      // Find record by ID or Pozo name (since dashboard uses pozo name)
      const record = records.find(r => r.id === recordId || r.pozo === recordId);
      if (!record) return;

      const recordRef = doc(db, 'esp_records', record.id);
      const updateData: any = {
        estadoInventario: newStatus,
        updatedAt: serverTimestamp()
      };

      if (newStatus === 'PULLING' && pullingData) {
        updateData.razonPulling = pullingData.razonPulling;
        updateData.razonEspecificaPulling = pullingData.razonEspecificaPulling;
        updateData.fechaPull = pullingData.fecha || new Date().toISOString().split('T')[0];

        if (pullingData.componentStatuses) {
          const s = pullingData.componentStatuses;

          // Helper to set status on components
          if (s['BOMBAS']) {
            updateData['fondo.pumpUpper.estadoPostPull'] = s['BOMBAS'];
          }
          if (s['INTAKE']) updateData['fondo.intakeSeparador.estadoPostPull'] = s['INTAKE'];
          if (s['PROTECTOR']) {
            updateData['fondo.protectorSuperior.estadoPostPull'] = s['PROTECTOR'];
          }
          if (s['MOTOR']) {
            updateData['fondo.motorUT.estadoPostPull'] = s['MOTOR'];
          }
          if (s['SENSOR']) updateData['fondo.sensor.estadoPostPull'] = s['SENSOR'];
          if (s['CABLE']) updateData['cable.cableFondo.estadoPostPull'] = s['CABLE'];
          if (s['VSD']) updateData['superficie.vsd.estadoPostPull'] = s['VSD'];
        }
      } else if (newStatus === 'FALLADO') {
        updateData.fechaFalla = fallaData?.fecha || new Date().toISOString().split('T')[0];
      }

      await updateDoc(recordRef, updateData);
      trackWrites(1);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `esp_records/${recordId}`);
    }
  };

  const handleMoveSkid = async (sourcePozo: string, targetPozo: string) => {
    if (isQuotaExceeded) {
      alert('Límite de cuota diaria alcanzado. No se puede realizar el movimiento.');
      return;
    }
    try {
      const batch = writeBatch(db);
      let writeCount = 0;

      let sourceRecord = records.find(r => r.pozo === sourcePozo);
      let targetRecord = records.find(r => r.pozo === targetPozo);

      if (sourcePozo === 'BASE') {
        // Moving from Base to a Well
        if (!targetRecord) throw new Error('Target well not found');
        const targetRef = doc(db, 'esp_records', targetRecord.id!);
        batch.update(targetRef, {
          'superficie.vsd.origen': 'BASE',
          updatedAt: serverTimestamp()
        });
        writeCount = 1;
      } else if (targetPozo === 'BASE') {
        // Moving from a Well to Base
        if (!sourceRecord) throw new Error('Source well not found');
        const sourceRef = doc(db, 'esp_records', sourceRecord.id!);
        batch.update(sourceRef, {
          'superficie.vsd': { serie: '', modelo: '', kva: '', controlador: '' },
          'superficie.filter': { serie: '', modelo: '' },
          'superficie.sut': { serie: '', kva: '' },
          updatedAt: serverTimestamp()
        });
        writeCount = 1;
      } else {
        // Well to Well
        if (!sourceRecord || !targetRecord) throw new Error('Source or Target well not found');

        const sourceRef = doc(db, 'esp_records', sourceRecord.id!);
        const targetRef = doc(db, 'esp_records', targetRecord.id!);

        // Copy surface data from source to target
        const surfaceData = { ...sourceRecord.superficie };
        if (surfaceData.vsd) {
          surfaceData.vsd.origen = sourcePozo;
        }

        batch.update(targetRef, {
          superficie: surfaceData,
          updatedAt: serverTimestamp()
        });

        // Clear source surface
        batch.update(sourceRef, {
          'superficie.vsd': { serie: '', modelo: '', kva: '', controlador: '' },
          'superficie.filter': { serie: '', modelo: '' },
          'superficie.sut': { serie: '', kva: '' },
          updatedAt: serverTimestamp()
        });
        writeCount = 2;
      }

      await batch.commit();
      trackWrites(writeCount);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'esp_records/move_skid');
    }
  };

  // Expose to window for Dashboard access
  React.useEffect(() => {
    (window as any).handleStatusUpdate = handleStatusUpdate;
  }, [records]);

  // Main App Layout
  if (!user && !authLoading) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex items-center justify-center p-4 font-sans">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl shadow-blue-100 p-8 border border-slate-100">
          <div className="text-center mb-8">
            <div className="bg-blue-600 w-16 h-16 rounded-2xl shadow-lg shadow-blue-200 flex items-center justify-center mx-auto mb-4">
              <Database className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight uppercase">ESP Master</h1>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mt-1">Inventory & Traceability</p>
          </div>

          <div className="space-y-4">
            <p className="text-sm text-slate-600 text-center mb-6">
              Bienvenido al sistema de gestión técnica. Por favor, inicie sesión con su cuenta autorizada para acceder a la base de datos.
            </p>
            
            <button
              onClick={handleLogin}
              className="w-full flex items-center justify-center space-x-3 bg-white border-2 border-slate-100 hover:border-blue-600 hover:bg-blue-50 text-slate-700 font-bold py-4 px-6 rounded-2xl transition-all group"
            >
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5" alt="Google" />
              <span>Iniciar Sesión con Google</span>
            </button>

            {lastError && (
              <div className="mt-4 p-4 bg-rose-50 border border-rose-100 rounded-2xl text-rose-700 text-[10px] font-bold uppercase tracking-tight leading-relaxed">
                {lastError}
              </div>
            )}
          </div>

          <div className="mt-8 pt-6 border-t border-slate-50 text-center">
            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
              © 2026 ALS Technical Services
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex items-center justify-center font-sans">
        <div className="text-center">
          <RefreshCw className="w-10 h-10 text-blue-600 animate-spin mx-auto mb-4" />
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Verificando Credenciales...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] flex font-sans selection:bg-blue-100 selection:text-blue-900">
      {/* Quota Warning Banner */}
      {(isQuotaExceeded || isReadQuotaExceeded) && (
        <div className={`fixed top-0 left-0 right-0 ${isReadQuotaExceeded ? 'bg-amber-500' : 'bg-rose-600'} text-white px-4 py-2 text-center text-[10px] font-black uppercase tracking-[0.2em] z-[100] shadow-lg animate-pulse flex items-center justify-center gap-3`}>
          <AlertCircle className="w-4 h-4" />
          {isReadQuotaExceeded 
            ? "Modo Lectura desde Caché: Límite de lectura de Firebase excedido. Los datos pueden no estar actualizados."
            : "Límite de cuota diaria alcanzado (20,000 escrituras). El sistema se restablecerá mañana."}
        </div>
      )}

      {/* Sidebar - More depth */}
      <aside className="w-56 bg-white border-r border-slate-100 flex flex-col fixed h-full z-30 shadow-[4px_0_24px_rgba(0,0,0,0.02)]">
        <div className="p-5">
          <div className="flex items-center space-x-3 mb-1">
            <div className="bg-blue-600 p-2 rounded-xl shadow-lg shadow-blue-200">
              <Database className="w-5 h-5 text-white" />
            </div>
            <span className="text-base font-black text-slate-900 tracking-tighter uppercase">ESP Master</span>
          </div>
          <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Inventory System</p>
        </div>

        <nav className="flex-1 px-3 space-y-1 overflow-y-auto custom-scrollbar">
          <div className="pb-3 px-4">
            <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Principal</p>
          </div>
          <NavItem
            active={view === 'dashboard'}
            onClick={() => setView('dashboard')}
            icon={LayoutDashboard}
            label="Dashboard"
          />
          <NavItem
            active={view === 'list'}
            onClick={() => setView('list')}
            icon={List}
            label="Inventario"
          />
          <NavItem
            active={view === 'movements'}
            onClick={() => setView('movements')}
            icon={ArrowRightLeft}
            label="Movimientos"
          />
          <NavItem
            active={view === 'equipment'}
            onClick={() => setView('equipment')}
            icon={History}
            label="Trazabilidad"
          />

          <div className="pt-6 pb-3 px-4">
            <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Operaciones</p>
          </div>
          <NavItem
            active={view === 'form'}
            onClick={() => setView('form')}
            icon={Plus}
            label="Nuevo Registro"
          />
          <NavItem
            active={showImport && view === 'list'}
            onClick={() => {
              setView('list');
              setShowImport(true);
            }}
            icon={FileSpreadsheet}
            label="Importar Excel"
          />
          <NavItem
            active={false}
            onClick={() => setShowClearConfirm(true)}
            icon={X}
            label="Limpiar Datos"
          />

          <div className="pt-6 pb-3 px-4">
            <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Herramientas</p>
          </div>
          <NavItem
            active={false}
            onClick={() => handleExportToExcel(records)}
            icon={Download}
            label="Exportar CSV"
          />
          <NavItem
            active={isSyncingAzure}
            onClick={handleAzureSync}
            icon={Cloud}
            label={isSyncingAzure ? "Sincronizando..." : "Sincronizar Azure"}
          />
        </nav>

        <div className="p-4 border-t border-gray-50 bg-gray-50/50 space-y-3">
          {/* Quota Indicator */}
          <div className="px-3 py-3 bg-white rounded-2xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Cuota de Escritura</span>
              <span className={`text-[9px] font-black uppercase ${isQuotaExceeded ? 'text-rose-600' : 'text-blue-600'}`}>
                {Math.round((dailyWrites / WRITE_LIMIT) * 100)}%
              </span>
            </div>
            <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden mb-2">
              <div 
                className={`h-full transition-all duration-500 ${isQuotaExceeded ? 'bg-rose-500' : 'bg-blue-500'}`}
                style={{ width: `${Math.min((dailyWrites / WRITE_LIMIT) * 100, 100)}%` }}
              />
            </div>
            <p className="text-[8px] font-bold text-gray-400 uppercase tracking-tighter">
              {dailyWrites.toLocaleString()} / {WRITE_LIMIT.toLocaleString()} escrituras hoy
            </p>
          </div>

          <div className="px-3 py-2 flex items-center space-x-3 bg-white rounded-2xl border border-gray-100 shadow-sm">
            <div className="bg-blue-100 p-1.5 rounded-full">
              <Database className="w-3.5 h-3.5 text-blue-600" />
            </div>
            <div className="overflow-hidden">
              <p className="text-[10px] font-black text-gray-900 truncate">{user?.displayName || 'Usuario'}</p>
              <button 
                onClick={handleLogout}
                className="text-[8px] font-bold text-blue-600 hover:text-blue-800 truncate uppercase tracking-tighter text-left"
              >
                Cerrar Sesión
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content - Improved background */}
      <main className="flex-1 ml-56 p-6 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:24px_24px] relative overflow-x-hidden">
        <header className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight uppercase">
              {view === 'dashboard' ? 'Panel de Control' : view === 'list' ? 'Inventario Maestro' : view === 'form' ? 'Registro Técnico' : view === 'movements' ? 'Gestión de Movimientos' : 'Historial de Equipos'}
            </h1>
            <div className="flex items-center space-x-2 mt-1">
              <div className="w-6 h-1 bg-blue-600 rounded-full" />
              <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Gestión técnica y trazabilidad de sistemas ESP</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            {(import.meta as any).env.VITE_EXCEL_ONLINE_URL && (
              <a 
                href={(import.meta as any).env.VITE_EXCEL_ONLINE_URL} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center space-x-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl shadow-sm transition-all duration-200 group"
              >
                <FileSpreadsheet className="w-4 h-4 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-black uppercase tracking-widest">Excel Online</span>
              </a>
            )}
            
            <div className={`flex items-center space-x-2 px-4 py-2 rounded-2xl shadow-sm border transition-all duration-500 ${
              connectionStatus === 'connected' ? 'bg-emerald-50 border-emerald-100 text-emerald-700' :
              connectionStatus === 'connecting' ? 'bg-blue-50 border-blue-100 text-blue-700' :
              connectionStatus === 'offline' ? 'bg-gray-50 border-gray-100 text-gray-700' :
              'bg-rose-50 border-rose-100 text-rose-700'
            }`}>
              <div className={`w-1.5 h-1.5 rounded-full ${
                connectionStatus === 'connected' ? 'bg-emerald-500 animate-pulse' :
                connectionStatus === 'connecting' ? 'bg-blue-500 animate-pulse' :
                connectionStatus === 'offline' ? 'bg-gray-500' :
                'bg-rose-500 animate-ping'
              }`} />
              <span className="text-[9px] font-black uppercase tracking-widest">
                {connectionStatus === 'connected' ? 'Base de Datos Online' :
                 connectionStatus === 'connecting' ? 'Conectando...' :
                 connectionStatus === 'offline' ? 'Modo Offline' :
                 'Error de Conexión'}
              </span>
            </div>
          </div>
        </header>

        {lastError && connectionStatus === 'error' && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            className="bg-rose-600 text-white px-8 py-3 flex items-center justify-between shadow-lg"
          >
            <div className="flex items-center space-x-3">
              <AlertTriangle className="w-5 h-5" />
              <div>
                <p className="text-xs font-black uppercase tracking-widest">Error de Conexión Detectado</p>
                <p className="text-[10px] opacity-90 font-medium">{lastError}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button 
                onClick={forceReload}
                className="px-4 py-1 bg-rose-500 text-white border border-white/20 rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-rose-400 transition-all"
              >
                Limpiar Caché
              </button>
              <button 
                onClick={() => setPauseSnapshot(!pauseSnapshot)}
                className="px-4 py-1 bg-white text-rose-600 rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-rose-50 transition-all"
              >
                Reintentar
              </button>
            </div>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          {view === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              <DashboardCards stats={stats} />

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white p-8 rounded-3xl shadow-sm border border-black/5 flex flex-col">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-bold text-gray-900">Estado de Conexión</h3>
                    <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${connectionStatus === 'connected' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                      {connectionStatus === 'connected' ? 'Estable' : 'Inestable'}
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                      <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Firestore</span>
                      <span className={`text-[10px] font-black uppercase tracking-widest ${connectionStatus === 'connected' ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {connectionStatus === 'connected' ? 'Conectado' : connectionStatus === 'connecting' ? 'Conectando...' : 'Error'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                      <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Servidor API</span>
                      <span className={`text-[10px] font-black uppercase tracking-widest ${serverHealth?.status === 'ok' ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {serverHealth?.status === 'ok' ? 'En Línea' : 'Fuera de Línea'}
                      </span>
                    </div>
                    <button 
                      onClick={forceReload}
                      className="w-full py-3 bg-gray-100 text-gray-900 font-bold rounded-xl hover:bg-gray-200 transition-all flex items-center justify-center space-x-2 text-[10px] uppercase tracking-widest"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Refrescar Conexión</span>
                    </button>
                  </div>
                </div>

                <div className="bg-white p-8 rounded-3xl shadow-sm border border-black/5">
                  <h3 className="text-lg font-bold text-gray-900 mb-6">Actividad Reciente</h3>
                  <div className="space-y-4">
                    {records.length === 0 ? (
                      <div className="text-center py-12">
                        <p className="text-gray-400 italic mb-4">No hay registros recientes</p>
                        <button
                          onClick={() => setView('form')}
                          className="text-blue-600 font-bold hover:underline"
                        >
                          Crear primer registro
                        </button>
                      </div>
                    ) : (
                      records.slice(0, 5).map(record => (
                        <div key={record.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
                          <div className="flex items-center space-x-4">
                            <div className={`w-2 h-2 rounded-full ${record.estadoInventario === 'OPERATIVO' ? 'bg-emerald-500' : record.estadoInventario === 'FALLADO' ? 'bg-rose-500' : 'bg-amber-500'}`} />
                            <div>
                              <p className="font-bold text-gray-900">{record.pozo}</p>
                              <p className="text-xs text-gray-500">{record.nick} • {record.proveedor}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium text-gray-900">{record.runLife} días</p>
                            <p className="text-xs text-gray-400">Run Life</p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="bg-white p-8 rounded-3xl shadow-sm border border-black/5 flex flex-col items-center justify-center text-center">
                  <div className="bg-blue-50 p-4 rounded-2xl mb-4">
                    <Plus className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">Nuevo Registro</h3>
                  <p className="text-gray-500 mb-6 max-w-xs">Capture los datos técnicos de un nuevo sistema o actualice uno existente.</p>
                  <button
                    onClick={() => setView('form')}
                    className="px-8 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
                  >
                    Empezar Registro
                  </button>
                </div>

                <div className="bg-white p-8 rounded-3xl shadow-sm border border-black/5 flex flex-col items-center justify-center text-center">
                  <div className="bg-emerald-50 p-4 rounded-2xl mb-4">
                    <FileSpreadsheet className="w-8 h-8 text-emerald-600" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">Carga Masiva</h3>
                  <p className="text-gray-500 mb-6 max-w-xs">¿Tienes un Excel? Sube toda tu base de datos de una sola vez.</p>
                  <button
                    onClick={() => {
                      setView('list');
                      setShowImport(true);
                    }}
                    className="px-8 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                  >
                    Importar Excel
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {view === 'form' && (
            <motion.div
              key="form"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
            >
              <ESPForm onSubmit={handleAddRecord} />
            </motion.div>
          )}

          {view === 'movements' && (
            <motion.div
              key="movements"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Movements
                records={records}
                onMoveSkid={handleMoveSkid}
              />
            </motion.div>
          )}

          {view === 'equipment' && (
            <motion.div
              key="equipment"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
            >
              <EquipmentTracker records={records} />
            </motion.div>
          )}

          {view === 'list' && (
            <motion.div
              key="list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between bg-white p-6 rounded-[2.5rem] border border-black/5 shadow-sm">
                <div className="flex items-center space-x-6">
                  <h2 className="text-lg font-black text-gray-900 uppercase tracking-widest">Inventario Maestro</h2>
                  <div className="h-8 w-px bg-gray-100" />
                  <button
                    onClick={() => setShowImport(!showImport)}
                    className={`flex items-center px-6 py-2.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${showImport ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' : 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'}`}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {showImport ? 'Cerrar Importador' : 'Importar Excel'}
                  </button>
                </div>

                {categoryFilter && (
                  <div className="flex items-center space-x-3 bg-blue-50 px-4 py-2 rounded-2xl border border-blue-100 animate-pulse">
                    <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Filtro: {categoryFilter}</span>
                    <button onClick={() => setCategoryFilter(null)} className="p-1 hover:bg-blue-100 rounded-full transition-colors">
                      <X className="w-3 h-3 text-blue-600" />
                    </button>
                  </div>
                )}
              </div>

              {showImport && (
                <>
                  <div className="mb-4 p-4 bg-amber-50 border border-amber-100 rounded-2xl flex items-start space-x-3">
                    <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
                    <div>
                      <p className="text-xs font-bold text-amber-800 uppercase tracking-wider mb-1">Aviso de Cuota</p>
                      <p className="text-xs text-amber-700 leading-relaxed">
                        El sistema procesará la totalidad de su archivo automáticamente.
                        Asegúrese de no cerrar la ventana hasta que la barra de progreso llegue al 100%.
                      </p>
                    </div>
                  </div>
                  <ExcelImport onImport={handleBulkImport} />
                  {importProgress && (
                    <div className="mt-4 p-6 bg-blue-50 rounded-3xl border border-blue-100">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex flex-col">
                          <span className="text-sm font-bold text-blue-700">Sincronizando Base de Datos...</span>
                          <span className="text-[10px] text-blue-500 font-medium uppercase tracking-tighter">Cargando registros al sistema</span>
                        </div>
                        <span className="text-sm font-bold text-blue-700">{Math.round((importProgress.current / importProgress.total) * 100)}%</span>
                      </div>
                      <div className="w-full bg-blue-200 rounded-full h-2.5">
                        <div
                          className="bg-blue-600 h-2.5 rounded-full transition-all duration-300"
                          style={{ width: `${(importProgress.current / importProgress.total) * 100}%` }}
                        ></div>
                      </div>
                      <p className="text-xs text-blue-500 mt-2">Procesando {importProgress.current} de {importProgress.total} pozos</p>
                    </div>
                  )}
                </>
              )}

              {view === 'list' && (
                <InventoryList
                  records={records}
                  onViewDetails={setSelectedRecord}
                  onStatusUpdate={handleStatusUpdate}
                  onDelete={(record) => {
                    setSelectedRecord(record);
                    setShowIndividualDeleteConfirm(true);
                  }}
                />
              )}
            </motion.div>
          )}

          {view === 'settings' && (
            <motion.div
              key="settings"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white p-8 rounded-[2.5rem] border border-black/5 shadow-sm"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Ajustes del Sistema</h2>
                  <p className="text-sm text-gray-500">Gestione el estado y mantenimiento de sus datos.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Diagnostic Info */}
                <div className="p-6 bg-gray-50 rounded-[2rem] border border-gray-100 flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-gray-600 text-white rounded-2xl shadow-lg shadow-gray-200">
                      <Settings className="w-6 h-6" />
                    </div>
                    <span className="px-3 py-1 bg-gray-200 text-gray-600 text-[9px] font-black rounded-full uppercase tracking-widest">Diagnóstico</span>
                  </div>
                  <h3 className="text-lg font-black text-gray-900 mb-3 uppercase tracking-tight">Estado del Sistema</h3>
                  <div className="space-y-3 flex-grow">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-500">Conexión Firestore:</span>
                      <span className={`font-bold ${connectionStatus === 'connected' ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {connectionStatus.toUpperCase()}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-500">Servidor API:</span>
                      <span className={`font-bold ${serverHealth?.status === 'ok' ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {serverHealth ? serverHealth.status.toUpperCase() : 'VERIFICANDO...'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-500">Registros:</span>
                      <span className="font-bold text-gray-900">{records.length}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-500">Proyecto:</span>
                      <span className="font-mono text-[10px] text-gray-400">{firebaseConfig.projectId}</span>
                    </div>
                    {lastError && (
                      <div className="mt-2 p-2 bg-rose-50 rounded-lg border border-rose-100">
                        <p className="text-[8px] font-black text-rose-400 uppercase tracking-widest mb-1">Error Firestore</p>
                        <p className="text-[9px] text-rose-700 font-mono break-all leading-tight">{lastError}</p>
                      </div>
                    )}
                    <div className="pt-4 space-y-2">
                      <button
                        onClick={forceReload}
                        className="w-full py-2 bg-gray-900 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-gray-800 transition-all"
                      >
                        Limpiar Caché y Reconectar
                      </button>
                      <button
                        onClick={checkServerHealth}
                        className="w-full py-2 bg-white text-gray-900 border border-gray-200 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-gray-50 transition-all"
                      >
                        Re-verificar Servidor
                      </button>
                    </div>
                  </div>
                </div>

                {/* Quota Maintenance */}
                <div className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100 flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-slate-600 text-white rounded-2xl shadow-lg shadow-slate-200">
                      <RefreshCw className="w-6 h-6" />
                    </div>
                    <span className="px-3 py-1 bg-slate-200 text-slate-600 text-[10px] font-bold rounded-full">SISTEMA</span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2">Mantenimiento de Cuota</h3>
                  <p className="text-sm text-slate-500 mb-6 flex-grow">
                    Si sabes que la cuota de Firebase se ha reiniciado (nuevo día) pero el contador local sigue bloqueado, puedes reiniciarlo aquí.
                  </p>
                  <button
                    onClick={resetQuotaCounter}
                    className="w-full py-3 bg-white text-slate-900 border border-slate-200 font-bold rounded-xl hover:bg-slate-50 transition-all flex items-center justify-center space-x-2"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>Reiniciar Contador</span>
                  </button>
                </div>
              </div>

              <div className="mt-8 p-6 bg-rose-50 rounded-[2rem] border border-rose-100">
                <h3 className="font-bold text-rose-900 mb-2">Zona de Peligro</h3>
                <p className="text-sm text-rose-600 mb-4">Estas acciones son irreversibles. Procede con precaución.</p>
                <button
                  onClick={() => setShowClearConfirm(true)}
                  className="px-6 py-3 bg-rose-600 text-white font-bold rounded-xl hover:bg-rose-700 transition-all shadow-lg shadow-rose-100"
                >
                  Borrar Toda la Base de Datos
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Record Detail Modal */}
        <AnimatePresence>
          {selectedRecord && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col"
              >
                <div className="p-8 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{selectedRecord.pozo}</h2>
                    <p className="text-gray-500">Detalles técnicos del sistema ESP</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {showIndividualDeleteConfirm ? (
                      <div className="flex items-center bg-rose-50 rounded-xl px-3 py-1 border border-rose-100 space-x-3">
                        <span className="text-xs font-bold text-rose-600 uppercase">¿Eliminar?</span>
                        <button
                          onClick={() => {
                            handleDeleteRecord(selectedRecord.id!);
                            setShowIndividualDeleteConfirm(false);
                          }}
                          className="text-xs font-bold text-rose-700 hover:underline"
                        >
                          Sí
                        </button>
                        <button
                          onClick={() => setShowIndividualDeleteConfirm(false)}
                          className="text-xs font-bold text-gray-500 hover:underline"
                        >
                          No
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setShowIndividualDeleteConfirm(true)}
                        className="p-2 hover:bg-rose-100 rounded-xl transition-colors text-rose-600"
                        title="Eliminar Registro"
                      >
                        <Trash2 className="w-6 h-6" />
                      </button>
                    )}
                    <button
                      onClick={() => {
                        setSelectedRecord(null);
                        setShowIndividualDeleteConfirm(false);
                      }}
                      className="p-2 hover:bg-gray-200 rounded-xl transition-colors"
                    >
                      <X className="w-6 h-6 text-gray-500" />
                    </button>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto p-8 space-y-8">
                  {/* Segmented Equipment Blocks */}
                  <div className="grid grid-cols-1 gap-8">
                    {/* Superficie Block */}
                    <div className="bg-white rounded-[2rem] border border-blue-100 shadow-sm overflow-hidden">
                      <div className="bg-blue-600 p-4 flex items-center justify-between">
                        <div className="flex items-center space-x-3 text-white">
                          <Box className="w-6 h-6" />
                          <h3 className="font-bold text-lg">Equipo de Superficie</h3>
                        </div>
                        <span className="text-blue-100 text-xs font-bold uppercase tracking-widest">Identificado</span>
                      </div>
                      <div className="p-8 flex flex-col md:flex-row gap-8 items-start">
                        <div className="w-full md:w-32 flex justify-center bg-blue-50/50 p-6 rounded-3xl">
                          <Box className="w-16 h-16 text-blue-600" />
                        </div>
                        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
                          <DetailRow label="Marca VSD" value={selectedRecord.superficie?.vsd?.marca} />
                          <DetailRow label="Modelo VSD" value={selectedRecord.superficie?.vsd?.modelo} />
                          <DetailRow label="KVA VSD" value={selectedRecord.superficie?.vsd?.kva} />
                          <DetailRow label="Controlador" value={selectedRecord.superficie?.vsd?.controlador} />
                          <DetailRow label="Amp Out" value={selectedRecord.superficie?.vsd?.ampOut} />
                          <DetailRow label="Pulsos" value={selectedRecord.superficie?.vsd?.pulsos} />
                          <DetailRow label="Filtro S/N" value={selectedRecord.superficie?.filter?.sn} />
                          <DetailRow label="Filtro KVA" value={selectedRecord.superficie?.filter?.kva} />
                          <DetailRow label="SUT Marca" value={selectedRecord.superficie?.sut?.marca} />
                          <DetailRow label="SUT S/N" value={selectedRecord.superficie?.sut?.sn} />
                          <DetailRow label="SUT KVA" value={selectedRecord.superficie?.sut?.kva} />
                        </div>
                      </div>
                    </div>

                    {/* Fondo Block */}
                    <div className="bg-white rounded-[2rem] border border-emerald-100 shadow-sm overflow-hidden">
                      <div className="bg-emerald-600 p-4 flex items-center justify-between">
                        <div className="flex items-center space-x-3 text-white">
                          <Anchor className="w-6 h-6" />
                          <h3 className="font-bold text-lg">Equipo de Fondo</h3>
                        </div>
                        <span className="text-emerald-100 text-xs font-bold uppercase tracking-widest">Identificado</span>
                      </div>
                      <div className="p-8 flex flex-col md:flex-row gap-8 items-start">
                        <div className="w-full md:w-32 flex justify-center bg-emerald-50/50 p-6 rounded-3xl">
                          <Anchor className="w-16 h-16 text-emerald-600" />
                        </div>
                        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
                          <DetailRow label="Tecnología Motor" value={selectedRecord.fondo?.tecMotor} />
                          <DetailRow label="Motor UT S/N" value={selectedRecord.fondo?.motorUT?.sn} />
                          <DetailRow label="Motor UT Desc." value={selectedRecord.fondo?.motorUT?.descripcion} />
                          <DetailRow label="Motor UT HP" value={selectedRecord.fondo?.motorUT?.hp} />
                          <DetailRow label="Motor UT VOL." value={selectedRecord.fondo?.motorUT?.vol} />
                          <DetailRow label="Motor UT AMP." value={selectedRecord.fondo?.motorUT?.amp} />
                          <DetailRow label="Pump Upper Modelo" value={selectedRecord.fondo?.pumpUpper?.modelo} />
                          <DetailRow label="Sensor S/N" value={selectedRecord.fondo?.sensor?.sn} />
                          <DetailRow label="Intake/Separador S/N" value={selectedRecord.fondo?.intakeSeparador?.sn} />
                          {selectedRecord.yTool?.sn && (
                            <DetailRow label="Y-TOOL S/N" value={selectedRecord.yTool.sn} />
                          )}
                        </div>
                        {selectedRecord.fondo?.espSummary && (
                          <div className="w-full p-6 bg-emerald-50/50 rounded-3xl border border-emerald-100 shadow-inner">
                            <div className="flex items-center space-x-2 mb-3">
                              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                              <p className="text-xs font-bold text-emerald-700 uppercase tracking-wider">Resumen BHA (ESP)</p>
                            </div>
                            <p className="text-sm text-gray-700 font-medium leading-relaxed whitespace-pre-wrap">{selectedRecord.fondo.espSummary}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Cable Block */}
                    <div className="bg-white rounded-[2rem] border border-amber-100 shadow-sm overflow-hidden">
                      <div className="bg-amber-600 p-4 flex items-center justify-between">
                        <div className="flex items-center space-x-3 text-white">
                          <Zap className="w-6 h-6" />
                          <h3 className="font-bold text-lg">Cable de Fondo</h3>
                        </div>
                        <span className="text-amber-100 text-xs font-bold uppercase tracking-widest">Identificado</span>
                      </div>
                      <div className="p-8 flex flex-col md:flex-row gap-8 items-start">
                        <div className="w-full md:w-32 flex justify-center bg-amber-50/50 p-6 rounded-3xl">
                          <Zap className="w-16 h-16 text-amber-600" />
                        </div>
                        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-4">
                          <DetailRow label="MLE P/N" value={selectedRecord.cable?.mle?.pn} />
                          <DetailRow label="Cable P/N" value={selectedRecord.cable?.cableFondo?.pn} />
                          <DetailRow label="Longitud" value={selectedRecord.cable?.cableFondo?.longitud} />
                          <DetailRow label="AWG" value={selectedRecord.cable?.cableFondo?.awg} />
                        </div>
                      </div>
                    </div>

                    {/* General Info Block */}
                    <div className="bg-gray-50 rounded-[2rem] p-8 border border-gray-100">
                      <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center">
                        <LayoutDashboard className="w-5 h-5 mr-2 text-blue-600" />
                        Información de Instalación
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <DetailRow label="Nick" value={selectedRecord.nick} />
                        <DetailRow label="Activo" value={selectedRecord.activo} />
                        <DetailRow label="Bloque" value={selectedRecord.bloque} />
                        <DetailRow label="Campo" value={selectedRecord.campo} />
                        <DetailRow label="Proveedor" value={selectedRecord.proveedor} />
                        <DetailRow label="Fecha Run" value={selectedRecord.fechaRun} />
                        <DetailRow label="Indicador MTBF" value={selectedRecord.indicadorMTBF} />
                        <DetailRow label="Pozo Fallado" value={selectedRecord.pozoFallado ? 'Sí' : 'No'} />
                        <DetailRow label="Caso Estudio" value={selectedRecord.casoEstudio ? 'Sí' : 'No'} />
                        <DetailRow label="Fase a Tierra" value={selectedRecord.operandoFaseTierra ? 'Sí' : 'No'} />
                        <DetailRow label="Link Carpeta" value={selectedRecord.linkCarpeta ? <a href={selectedRecord.linkCarpeta} target="_blank" className="text-blue-600 underline">Ver</a> : 'N/A'} />
                        <DetailRow label="Link Carpetas" value={selectedRecord.linkCarpetas ? <a href={selectedRecord.linkCarpetas} target="_blank" className="text-blue-600 underline">Ver</a> : 'N/A'} />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Clear Database Confirmation Modal */}
        <AnimatePresence>
          {showClearConfirm && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden text-center p-8"
              >
                <div className="bg-rose-50 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6">
                  <AlertCircle className="w-10 h-10 text-rose-600" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">¿Borrar Base de Datos?</h2>
                <p className="text-gray-500 mb-2 leading-relaxed">
                  Esta acción eliminará permanentemente los <strong>{records.length} registros</strong> actuales.
                </p>
                <div className="grid grid-cols-2 gap-4 mt-8">
                  <button
                    onClick={() => setShowClearConfirm(false)}
                    className="py-3 px-6 bg-gray-100 text-gray-700 font-bold rounded-xl hover:bg-gray-200 transition-all"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={handleClearDatabase}
                    disabled={isClearing}
                    className="py-3 px-6 bg-rose-600 text-white font-bold rounded-xl hover:bg-rose-700 transition-all shadow-lg shadow-rose-100 flex items-center justify-center"
                  >
                    {isClearing ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      'Sí, Borrar Todo'
                    )}
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppContent />
    </ErrorBoundary>
  );
}

const NavItem: React.FC<{ active: boolean; onClick: () => void; icon: any; label: string }> = ({ active, onClick, icon: Icon, label }) => (
  <button
    onClick={onClick}
    className={`flex items-center w-full px-4 py-3 text-sm font-medium rounded-xl transition-all ${active
      ? 'bg-blue-50 text-blue-600 shadow-sm shadow-blue-100'
      : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
      }`}
  >
    <Icon className={`w-5 h-5 mr-3 ${active ? 'text-blue-600' : 'text-gray-400'}`} />
    {label}
  </button>
);

const DetailRow: React.FC<{ label: string; value: any }> = ({ label, value }) => (
  <div className="flex justify-between py-2 border-b border-gray-50">
    <span className="text-sm text-gray-400 font-medium">{label}</span>
    <span className="text-sm text-gray-900 font-bold">{value || 'N/A'}</span>
  </div>
);
