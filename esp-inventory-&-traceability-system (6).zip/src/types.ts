export interface EquipmentComponent {
  estado?: 'NEW' | 'USED' | 'REP';
  serie?: string;
  etapas?: string;
  modelo?: string;
  descripcion?: string;
  pn?: string;
  sn?: string;
  hp?: string;
  vol?: string;
  amp?: string;
  longitud?: string;
  awg?: string;
  tipo?: string; // Plano/Redondo
  kva?: string;
  controlador?: string;
  ampOut?: string;
  pulsos?: string;
  marca?: string;
  profundidad?: string;
  estadoPostPull?: 'REPARACIÓN' | 'REMANUFACTURA' | 'INSPECCIÓN' | 'PERDIDO' | 'BUENO PARA USAR' | 'SCRAP' | 'PENDIENTE';
}

export interface ESPRecord {
  id?: string;
  excelRowIdx?: number;
  timestamp: string;
  uid?: string;

  // Información General
  nick: string;
  activo: string;
  bloque: string;
  campo: string;
  cluster: string;
  pozo: string;
  runNumber: number;
  als: string;
  proveedor: string;

  // Tiempos y Estado de Inventario
  fechaRun: string;
  fechaFalla?: string;
  fechaPull?: string;
  estadoInventario: 'OPERATIVO' | 'FALLADO' | 'PULLING';
  runLife: number;

  // Downhole (Fondo)
  fondo: {
    pumpGasHandled: EquipmentComponent;
    pumpLower: EquipmentComponent;
    pumpCentralA: EquipmentComponent;
    pumpCentralB: EquipmentComponent;
    pumpCentralC: EquipmentComponent;
    pumpCentralD: EquipmentComponent;
    pumpUpper: EquipmentComponent;
    intakeSeparador: EquipmentComponent;
    protectorSuperior: EquipmentComponent;
    protectorCentral: EquipmentComponent;
    protectorInferior: EquipmentComponent;
    motorUT: EquipmentComponent;
    motorCT: EquipmentComponent;
    motorLT: EquipmentComponent;
    tecMotor: string;
    sensor: EquipmentComponent;
    espSummary?: string;
  };

  // Cable
  cable: {
    mle: EquipmentComponent;
    cableFondo: EquipmentComponent;
    estado2?: string; // Estado post-pulling (reparar, remanofactura, inspección, etc.)
  };

  // Surface (Superficie)
  superficie: {
    vsd: EquipmentComponent & { origen?: string };
    filter: EquipmentComponent;
    sut: EquipmentComponent;
  };

  // Accesorios
  yTool?: EquipmentComponent;
  detalles?: string;

  // Razones de Pulling
  razonPulling?: string;
  razonEspecificaPulling?: string;
}

export interface DashboardStats {
  totalRecords: number;
  totalOperativos: number;
  totalFallados: number;
  totalPulling: number;
  avgRunLife: number;
  healthScore: number;
  mtbf: number; // Mean Time Between Failures
  totalPendingPostPull: number;

  // Distributions for charts
  statusDistribution: { name: string; value: number; color: string }[];
  providerDistribution: { name: string; value: number }[];
  campoDistribution: { name: string; value: number }[];
  kvaDistribution: { name: string; value: number }[];
  hpDistribution: { name: string; value: number }[];
  failureByProvider: { name: string; value: number }[];

  // Top performance
  topWells: { pozo: string; runLife: number; provider: string }[];
  recentFailures: { pozo: string; runLife: number; provider: string }[];
  avgRunLifeByProvider: { name: string; value: number }[];
  statusByCampo: { campo: string; operativo: number; fallado: number; pulling: number }[];
  runLifeDistribution: { range: string; count: number }[];

  // Equipment condition (Surface removed from new/used as per user request)
  equipmentCondition: {
    fondo: { new: number; used: number; rep: number };
    cable: { new: number; used: number; rep: number };
  };
}
