import React, { useState, useMemo } from 'react';
import {
    Search,
    Settings,
    History,
    Box,
    Zap,
    Anchor,
    Cpu,
    Layout,
    ChevronRight,
    Filter,
    ArrowRight,
    TrendingUp,
    Clock,
    MapPin,
    Calendar,
    X
} from 'lucide-react';
import { ESPRecord, EquipmentComponent } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface Props {
    records: ESPRecord[];
}

interface EquipmentEvent {
    pozo: string;
    fecha: string;
    status: string;
    runNumber: number;
    runLife: number;
    timestamp: string;
    estadoPostPull?: string;
}

interface EquipmentProfile {
    sn: string;
    pn: string;
    type: string;
    category: string;
    model: string;
    description: string;
    history: EquipmentEvent[];
    currentWell: string;
    currentStatus: string;
    totalRunLife: number;
    lastUpdate: string;
}

const CATEGORIES = [
    { id: 'BOMBAS', label: 'Bombas', icon: Anchor, color: 'bg-emerald-600' },
    { id: 'INTAKE', label: 'Intake / Sep.', icon: Layout, color: 'bg-cyan-600' },
    { id: 'PROTECTOR', label: 'Protectores', icon: Settings, color: 'bg-slate-600' },
    { id: 'MOTOR', label: 'Motores', icon: Cpu, color: 'bg-blue-600' },
    { id: 'SENSOR', label: 'Sensores', icon: TrendingUp, color: 'bg-purple-600' },
    { id: 'CABLE', label: 'Cable Fondo', icon: Zap, color: 'bg-amber-600' },
    { id: 'VSD', label: 'E. Superficie (VSD)', icon: Box, color: 'bg-indigo-600' },
    { id: 'OTROS', label: 'Otros / Acc.', icon: Layout, color: 'bg-rose-600' },
];

export const EquipmentTracker: React.FC<Props> = ({ records }) => {
    const [activeCategory, setActiveCategory] = useState('BOMBAS');
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedEquipment, setSelectedEquipment] = useState<EquipmentProfile | null>(null);

    const trackerData = useMemo(() => {
        const equipmentMap = new Map<string, EquipmentProfile>();

        // Helper to get component category
        const getCategory = (path: string): string => {
            const p = path.toLowerCase();
            if (p.includes('motor')) return 'MOTOR';
            if (p.includes('pump')) return 'BOMBAS';
            if (p.includes('protector')) return 'PROTECTOR';
            if (p.includes('vsd')) return 'VSD';
            if (p.includes('cable')) return 'CABLE'; // Simplified check
            if (p.includes('intake')) return 'INTAKE';
            if (p.includes('sensor')) return 'SENSOR';
            return 'OTROS';
        };

        // Sort records chronologically (oldest first)
        const sortedRecords = [...records].sort((a, b) =>
            new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
        );

        sortedRecords.forEach(record => {
            const components: { path: string; data: EquipmentComponent }[] = [
                { path: 'fondo.motorUT', data: record.fondo.motorUT },
                { path: 'fondo.pumpUpper', data: record.fondo.pumpUpper },
                { path: 'fondo.intakeSeparador', data: record.fondo.intakeSeparador },
                { path: 'fondo.protectorSuperior', data: record.fondo.protectorSuperior },
                { path: 'fondo.sensor', data: record.fondo.sensor },
                { path: 'cable.cableFondo', data: record.cable.cableFondo },
                { path: 'superficie.vsd', data: record.superficie.vsd },
            ];

            if (record.yTool) components.push({ path: 'yTool', data: record.yTool });

            components.forEach(({ path, data }) => {
                const sn = (data.serie || data.sn || '').trim();
                const pn = (data.pn || '').trim();

                // Both SN and PN must exist and match exactly to be the same equipment
                if (!sn || sn === '' || sn === 'N/A' || !pn || pn === '' || pn === 'N/A') return;

                const equipmentKey = `${pn}_${sn}`;
                const category = getCategory(path);

                if (!equipmentMap.has(equipmentKey)) {
                    equipmentMap.set(equipmentKey, {
                        sn,
                        pn,
                        type: path.split('.').pop() || 'Unknown',
                        category,
                        model: data.modelo || 'N/A',
                        description: data.descripcion || '',
                        history: [],
                        currentWell: '',
                        currentStatus: '',
                        totalRunLife: 0,
                        lastUpdate: '',
                    });
                }

                const profile = equipmentMap.get(equipmentKey)!;

                // Add event to history
                const event: EquipmentEvent = {
                    pozo: record.pozo,
                    fecha: record.fechaRun,
                    status: record.estadoInventario,
                    runNumber: record.runNumber,
                    runLife: record.runLife || 0,
                    timestamp: record.timestamp,
                    estadoPostPull: data.estadoPostPull,
                };

                // Avoid adding the exact same event if duplicated in records
                const isDuplicate = profile.history.some(h =>
                    h.pozo === event.pozo &&
                    h.runNumber === event.runNumber &&
                    h.status === event.status
                );

                if (!isDuplicate) {
                    profile.history.push(event);
                }

                // Update current status (since we are iterating chronologically, the last one is the current)
                profile.currentWell = record.pozo;
                profile.currentStatus = record.estadoInventario;
                profile.lastUpdate = record.timestamp;
            });
        });

        // Post-process to calculate total accumulated run life
        // This is tricky: we should sum the maximum run life achieved in each unique installation
        equipmentMap.forEach(profile => {
            const uniqueInstallations = new Map<string, number>();
            profile.history.forEach(ev => {
                const key = `${ev.pozo}_${ev.runNumber}`;
                const currentMax = uniqueInstallations.get(key) || 0;
                if (ev.runLife > currentMax) {
                    uniqueInstallations.set(key, ev.runLife);
                }
            });
            profile.totalRunLife = Array.from(uniqueInstallations.values()).reduce((a, b) => a + b, 0);

            // Sort history descending for display
            profile.history.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        });

        return Array.from(equipmentMap.values());
    }, [records]);

    const filteredEquipment = useMemo(() => {
        return trackerData.filter(item => {
            const matchesCategory = item.category === activeCategory;
            const matchesSearch =
                item.sn.toLowerCase().includes(searchTerm.toLowerCase()) ||
                item.pn.toLowerCase().includes(searchTerm.toLowerCase()) ||
                item.currentWell.toLowerCase().includes(searchTerm.toLowerCase()) ||
                item.model.toLowerCase().includes(searchTerm.toLowerCase());
            return matchesCategory && matchesSearch;
        });
    }, [trackerData, activeCategory, searchTerm]);

    return (
        <div className="space-y-8">
            {/* Search & Stats Header */}
            <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-black/5 flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="relative flex-1">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                        type="text"
                        placeholder="Buscar por Serie, PN, Pozo o Modelo..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all font-bold text-gray-900"
                    />
                </div>
                <div className="flex items-center space-x-2">
                    <div className="px-6 py-4 bg-blue-50 rounded-2xl border border-blue-100 flex flex-col items-center">
                        <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Equipos Únicos</span>
                        <span className="text-2xl font-black text-blue-700">{trackerData.length}</span>
                    </div>
                    <div className="px-6 py-4 bg-emerald-50 rounded-2xl border border-emerald-100 flex flex-col items-center">
                        <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">En Categoría</span>
                        <span className="text-2xl font-black text-emerald-700">{trackerData.filter(i => i.category === activeCategory).length}</span>
                    </div>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex items-center space-x-2 overflow-x-auto pb-4 no-scrollbar">
                {CATEGORIES.map(cat => (
                    <button
                        key={cat.id}
                        onClick={() => setActiveCategory(cat.id)}
                        className={`flex items-center space-x-3 px-6 py-4 rounded-2xl font-black uppercase tracking-widest text-xs transition-all whitespace-nowrap active:scale-95 ${activeCategory === cat.id
                            ? `${cat.color} text-white shadow-lg shadow-blue-200`
                            : 'bg-white text-gray-400 hover:bg-gray-50 border border-black/5'
                            }`}
                    >
                        <cat.icon className="w-5 h-5" />
                        <span>{cat.label}</span>
                    </button>
                ))}
            </div>

            {/* List Table */}
            <div className="bg-white rounded-[2.5rem] shadow-xl border border-black/5 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-gray-50/50">
                                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Equipo / Serie</th>
                                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">PN / Modelo</th>
                                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Ubicación Actual</th>
                                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Estado</th>
                                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">Run Life Total</th>
                                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Acciones</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {filteredEquipment.map((item) => (
                                <tr key={`${item.pn}_${item.sn}`} className="group hover:bg-blue-50/30 transition-all cursor-default">
                                    <td className="px-8 py-5">
                                        <div className="flex flex-col">
                                            <span className="text-sm font-black text-gray-900 group-hover:text-blue-700 transition-colors uppercase">{item.type}</span>
                                            <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md w-fit mt-1">{item.sn}</span>
                                        </div>
                                    </td>
                                    <td className="px-8 py-5">
                                        <div className="flex flex-col">
                                            <span className="text-sm font-bold text-gray-600 truncate max-w-[150px]">{item.pn}</span>
                                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{item.model}</span>
                                        </div>
                                    </td>
                                    <td className="px-8 py-5">
                                        <div className="flex items-center space-x-2">
                                            <MapPin className="w-4 h-4 text-gray-400" />
                                            <span className="text-sm font-black text-gray-900">{item.currentWell}</span>
                                        </div>
                                    </td>
                                    <td className="px-8 py-5">
                                        <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${item.currentStatus === 'OPERATIVO' ? 'bg-emerald-100 text-emerald-700' :
                                            item.currentStatus === 'FALLADO' ? 'bg-rose-100 text-rose-700' :
                                                'bg-amber-100 text-amber-700'
                                            }`}>
                                            {item.currentStatus}
                                        </span>
                                    </td>
                                    <td className="px-8 py-5 text-center">
                                        <div className="flex flex-col items-center">
                                            <div className="flex items-center space-x-1.5">
                                                <TrendingUp className="w-4 h-4 text-blue-500" />
                                                <span className="text-base font-black text-gray-900">{item.totalRunLife}</span>
                                            </div>
                                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Días Acumulados</span>
                                        </div>
                                    </td>
                                    <td className="px-8 py-5 text-right">
                                        <button
                                            onClick={() => setSelectedEquipment(item)}
                                            className="p-3 bg-white text-blue-600 rounded-xl hover:bg-blue-600 hover:text-white shadow-md shadow-blue-100 border border-blue-100 transition-all active:scale-90 flex items-center justify-center float-right"
                                            title="Ver Historial Completo"
                                        >
                                            <History className="w-5 h-5" />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            {filteredEquipment.length === 0 && (
                                <tr>
                                    <td colSpan={6} className="px-8 py-20 text-center">
                                        <div className="flex flex-col items-center justify-center text-gray-400">
                                            <Filter className="w-12 h-12 mb-4 opacity-20" />
                                            <p className="text-sm font-bold">No hay equipos registrados en esta categoría</p>
                                        </div>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* History Modal */}
            <AnimatePresence>
                {selectedEquipment && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95, y: 20 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95, y: 20 }}
                            className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col"
                        >
                            <div className="p-8 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                                <div className="flex items-center space-x-4">
                                    <div className={`p-4 rounded-2xl text-white ${CATEGORIES.find(c => c.id === selectedEquipment.category)?.color || 'bg-gray-900'} shadow-lg`}>
                                        <History className="w-8 h-8" />
                                    </div>
                                    <div>
                                        <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tight">Historial de Trazabilidad</h2>
                                        <p className="text-gray-500 font-bold flex items-center">
                                            <span className="text-blue-600 mr-2">{selectedEquipment.type}</span> • SN: {selectedEquipment.sn}
                                        </p>
                                    </div>
                                </div>
                                <button
                                    onClick={() => setSelectedEquipment(null)}
                                    className="p-3 hover:bg-white rounded-2xl transition-colors text-gray-400 hover:text-rose-600"
                                >
                                    <X className="w-8 h-8" />
                                </button>
                            </div>

                            <div className="flex-1 overflow-y-auto p-8">
                                {/* Stats Summary */}
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                                    <div className="bg-blue-50/50 p-6 rounded-3xl border border-blue-100">
                                        <div className="flex items-center space-x-3 mb-3">
                                            <Clock className="w-5 h-5 text-blue-600" />
                                            <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Vida Útil Acumulada</span>
                                        </div>
                                        <p className="text-4xl font-black text-gray-900">{selectedEquipment.totalRunLife} <span className="text-sm text-gray-400">días</span></p>
                                    </div>
                                    <div className="bg-emerald-50/50 p-6 rounded-3xl border border-emerald-100">
                                        <div className="flex items-center space-x-3 mb-3">
                                            <MapPin className="w-5 h-5 text-emerald-600" />
                                            <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Instalación Actual</span>
                                        </div>
                                        <p className="text-4xl font-black text-gray-900 uppercase">{selectedEquipment.currentWell}</p>
                                    </div>
                                    <div className="bg-purple-50/50 p-6 rounded-3xl border border-purple-100">
                                        <div className="flex items-center space-x-3 mb-3">
                                            <TrendingUp className="w-5 h-5 text-purple-600" />
                                            <span className="text-[10px] font-black text-purple-600 uppercase tracking-widest">Total Intervenciones</span>
                                        </div>
                                        <p className="text-4xl font-black text-gray-900">{selectedEquipment.history.length}</p>
                                    </div>
                                </div>

                                <h3 className="text-lg font-black text-gray-900 mb-6 uppercase tracking-widest flex items-center">
                                    <TrendingUp className="w-5 h-5 mr-3 text-blue-600" />
                                    Línea de Tiempo
                                </h3>

                                <div className="relative space-y-8 before:absolute before:left-6 before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-100">
                                    {selectedEquipment.history.map((event, idx) => (
                                        <div key={idx} className="relative pl-16">
                                            <div className="absolute left-0 w-12 h-12 bg-white border-2 border-blue-600 rounded-2xl flex items-center justify-center z-10 shadow-sm">
                                                {event.status === 'OPERATIVO' ? <TrendingUp className="w-5 h-5 text-emerald-500" /> : <History className="w-5 h-5 text-amber-500" />}
                                            </div>

                                            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:border-blue-200 transition-colors">
                                                <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 gap-2">
                                                    <div>
                                                        <span className="text-xs font-black text-gray-400 uppercase tracking-widest">{new Date(event.timestamp).toLocaleDateString()}</span>
                                                        <h4 className="text-xl font-black text-gray-900 uppercase">Pozo {event.pozo} <span className="text-sm text-blue-600 ml-2">RUN #{event.runNumber}</span></h4>
                                                    </div>
                                                    <span className={`px-4 py-1.5 rounded-xl text-xs font-black tracking-widest uppercase ${event.status === 'OPERATIVO' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                                                        }`}>
                                                        {event.status}
                                                    </span>
                                                </div>
                                                <div className="grid grid-cols-2 gap-4">
                                                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                                                        <Clock className="w-4 h-4" />
                                                        <span>Run Life en esta fase: <strong>{event.runLife} días</strong></span>
                                                    </div>
                                                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                                                        <Calendar className="w-4 h-4" />
                                                        <span>Fecha Run: <strong>{event.fecha}</strong></span>
                                                    </div>
                                                    {event.estadoPostPull && (
                                                        <div className="col-span-2 mt-2 p-3 bg-amber-50 rounded-xl border border-amber-100 flex items-center space-x-2">
                                                            <Settings className="w-4 h-4 text-amber-600" />
                                                            <span className="text-[10px] font-black text-amber-800 uppercase tracking-widest">Estado Post-Extracción: {event.estadoPostPull}</span>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="p-8 bg-gray-50 border-t border-gray-100 flex justify-end">
                                <button
                                    onClick={() => setSelectedEquipment(null)}
                                    className="px-10 py-4 bg-gray-900 text-white font-black rounded-2xl shadow-lg hover:bg-black transition-all uppercase tracking-widest text-xs"
                                >
                                    Cerrar
                                </button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};
