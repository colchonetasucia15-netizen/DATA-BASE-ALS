import React, { useState, useEffect } from 'react';
import { ESPRecord } from '../types';
import { PROVEEDORES, ESTADOS, RAZONES_PULL, CAMPOS, ACTIVOS, BLOQUES, ENFRIAMIENTO_VSD, ESTADO_FILTROS } from '../constants';
import { calculateRunLife } from '../utils';
import { Save, ChevronRight, ChevronLeft } from 'lucide-react';

interface Props {
  onSubmit: (record: ESPRecord) => void;
  initialData?: Partial<ESPRecord>;
}

const SECTIONS = [
  'Información General',
  'Fondo - Bombas 1',
  'Fondo - Bombas 2',
  'Fondo - Protectores y Motores 1',
  'Fondo - Motores 2 y Sensores',
  'Cable y MLE',
  'Superficie y Accesorios'
];

const INITIAL_FORM_STATE: ESPRecord = {
  timestamp: new Date().toISOString(),
  nick: '',
  activo: '',
  bloque: '',
  campo: '',
  cluster: '',
  pozo: '',
  runNumber: 1,
  als: 'ESP',
  proveedor: '',
  fechaRun: '',
  estadoInventario: 'OPERATIVO',
  runLife: 0,
  fondo: {
    pumpGasHandled: {},
    pumpLower: {},
    pumpCentralA: {},
    pumpCentralB: {},
    pumpCentralC: {},
    pumpCentralD: {},
    pumpUpper: {},
    intakeSeparador: {},
    protectorSuperior: {},
    protectorCentral: {},
    protectorInferior: {},
    motorUT: {},
    motorCT: {},
    motorLT: {},
    tecMotor: '',
    sensor: {},
  },
  cable: {
    mle: {},
    cableFondo: {},
  },
  superficie: {
    vsd: {},
    filter: {},
    sut: {},
  },
};

export const ESPForm: React.FC<Props> = ({ onSubmit, initialData }) => {
  const [activeSection, setActiveSection] = useState(0);
  const [formData, setFormData] = useState<ESPRecord>(() => {
    if (initialData) {
      return { ...INITIAL_FORM_STATE, ...initialData };
    }
    return INITIAL_FORM_STATE;
  });

  useEffect(() => {
    if (formData.fechaRun) {
      const runLife = calculateRunLife(formData.fechaRun, formData.fechaFalla, formData.fechaPull);
      setFormData(prev => ({ ...prev, runLife }));
    }
  }, [formData.fechaRun, formData.fechaFalla, formData.fechaPull]);

  const handleChange = (path: string, value: any) => {
    setFormData(prev => {
      const newData = { ...prev };
      const keys = path.split('.');
      let current: any = newData;
      for (let i = 0; i < keys.length - 1; i++) {
        current[keys[i]] = { ...current[keys[i]] };
        current = current[keys[i]];
      }
      current[keys[keys.length - 1]] = value;
      return newData;
    });
  };

  const renderComponentFields = (title: string, path: string, fields: string[]) => {
    const getVal = (p: string) => {
      const keys = p.split('.');
      let current: any = formData;
      for (const key of keys) {
        if (!current) return '';
        current = current[key];
      }
      return current || '';
    };

    return (
      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-4">
        <h4 className="font-bold text-gray-900 border-b pb-2 text-sm uppercase tracking-wider text-blue-600">{title}</h4>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {fields.includes('estado') && (
            <FormSelect
              label="Estado"
              value={getVal(`${path}.estado`)}
              options={['NEW', 'USED', 'REP']}
              onChange={v => handleChange(`${path}.estado`, v)}
            />
          )}
          {fields.includes('serie') && <FormField label="Serie/SN" value={getVal(`${path}.serie`)} onChange={v => handleChange(`${path}.serie`, v)} />}
          {fields.includes('etapas') && <FormField label="Etapas" value={getVal(`${path}.etapas`)} onChange={v => handleChange(`${path}.etapas`, v)} />}
          {fields.includes('modelo') && <FormField label="Modelo" value={getVal(`${path}.modelo`)} onChange={v => handleChange(`${path}.modelo`, v)} />}
          {fields.includes('descripcion') && <FormField label="Descripción" value={getVal(`${path}.descripcion`)} onChange={v => handleChange(`${path}.descripcion`, v)} />}
          {fields.includes('pn') && <FormField label="P/N" value={getVal(`${path}.pn`)} onChange={v => handleChange(`${path}.pn`, v)} />}
          {fields.includes('sn') && <FormField label="S/N" value={getVal(`${path}.sn`)} onChange={v => handleChange(`${path}.sn`, v)} />}
          {fields.includes('hp') && <FormField label="HP" value={getVal(`${path}.hp`)} onChange={v => handleChange(`${path}.hp`, v)} />}
          {fields.includes('vol') && <FormField label="Vol." value={getVal(`${path}.vol`)} onChange={v => handleChange(`${path}.vol`, v)} />}
          {fields.includes('amp') && <FormField label="Amp." value={getVal(`${path}.amp`)} onChange={v => handleChange(`${path}.amp`, v)} />}
          {fields.includes('longitud') && <FormField label="Longitud" value={getVal(`${path}.longitud`)} onChange={v => handleChange(`${path}.longitud`, v)} />}
          {fields.includes('awg') && <FormField label="AWG" value={getVal(`${path}.awg`)} onChange={v => handleChange(`${path}.awg`, v)} />}
          {fields.includes('tipo') && <FormSelect label="Tipo" value={getVal(`${path}.tipo`)} options={['Plano', 'Redondo']} onChange={v => handleChange(`${path}.tipo`, v)} />}
          {fields.includes('kva') && <FormField label="KVA" value={getVal(`${path}.kva`)} onChange={v => handleChange(`${path}.kva`, v)} />}
          {fields.includes('controlador') && <FormField label="Controlador" value={getVal(`${path}.controlador`)} onChange={v => handleChange(`${path}.controlador`, v)} />}
          {fields.includes('ampOut') && <FormField label="Amp Out" value={getVal(`${path}.ampOut`)} onChange={v => handleChange(`${path}.ampOut`, v)} />}
          {fields.includes('pulsos') && <FormField label="Pulsos" value={getVal(`${path}.pulsos`)} onChange={v => handleChange(`${path}.pulsos`, v)} />}
          {fields.includes('marca') && <FormField label="Marca" value={getVal(`${path}.marca`)} onChange={v => handleChange(`${path}.marca`, v)} />}
          {fields.includes('profundidad') && <FormField label="Profundidad" value={getVal(`${path}.profundidad`)} onChange={v => handleChange(`${path}.profundidad`, v)} />}
          {fields.includes('origen') && <FormField label="Origen" value={getVal(`${path}.origen`)} onChange={v => handleChange(`${path}.origen`, v)} />}
          {fields.includes('estado2') && <FormSelect label="Estado Post-Pulling" value={getVal(`${path}.estado2`)} options={['REPARACIÓN', 'REMANUFACTURA', 'INSPECCIÓN', 'PERDIDO', 'BUENO PARA USAR', 'SCRAP']} onChange={v => handleChange(`${path}.estado2`, v)} />}
        </div>
      </div>
    );
  };

  const renderSection = () => {
    switch (activeSection) {
      case 0:
        return (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <FormField label="Nick" value={formData.nick} onChange={v => handleChange('nick', v)} required />
            <FormSelect label="Activo" value={formData.activo} options={ACTIVOS} onChange={v => handleChange('activo', v)} required />
            <FormSelect label="Bloque" value={formData.bloque} options={BLOQUES} onChange={v => handleChange('bloque', v)} required />
            <FormSelect label="Campo" value={formData.campo} options={CAMPOS} onChange={v => handleChange('campo', v)} required />
            <FormField label="Cluster" value={formData.cluster} onChange={v => handleChange('cluster', v)} required />
            <FormField label="Pozo" value={formData.pozo} onChange={v => handleChange('pozo', v)} required />
            <FormField label="# Run" type="number" value={formData.runNumber} onChange={v => handleChange('runNumber', parseInt(v))} required />
            <FormField label="ALS" value={formData.als} onChange={v => handleChange('als', v)} />
            <FormSelect label="Proveedor" value={formData.proveedor} options={PROVEEDORES} onChange={v => handleChange('proveedor', v)} required />
            <FormField label="Fecha Run" type="date" value={formData.fechaRun} onChange={v => handleChange('fechaRun', v)} required />
            <FormField label="Fecha Falla" type="date" value={formData.fechaFalla} onChange={v => handleChange('fechaFalla', v)} />
            <FormField label="Fecha Pull" type="date" value={formData.fechaPull} onChange={v => handleChange('fechaPull', v)} />
            <FormSelect label="Estado Inventario" value={formData.estadoInventario} options={['OPERATIVO', 'FALLADO', 'PULLING']} onChange={v => handleChange('estadoInventario', v)} required />
          </div>
        );
      case 1:
        return (
          <div className="space-y-6">
            {renderComponentFields('Pump Gas Handled', 'fondo.pumpGasHandled', ['estado', 'serie', 'etapas', 'modelo', 'descripcion', 'pn', 'sn'])}
            {renderComponentFields('Pump Lower', 'fondo.pumpLower', ['estado', 'serie', 'etapas', 'modelo', 'descripcion', 'pn', 'sn'])}
            {renderComponentFields('Pump Central A', 'fondo.pumpCentralA', ['estado', 'serie', 'etapas', 'modelo', 'descripcion', 'pn', 'sn'])}
            {renderComponentFields('Pump Central B', 'fondo.pumpCentralB', ['estado', 'serie', 'etapas', 'modelo', 'descripcion', 'pn', 'sn'])}
          </div>
        );
      case 2:
        return (
          <div className="space-y-6">
            {renderComponentFields('Pump Central C', 'fondo.pumpCentralC', ['estado', 'serie', 'etapas', 'modelo', 'descripcion', 'pn', 'sn'])}
            {renderComponentFields('Pump Central D', 'fondo.pumpCentralD', ['estado', 'serie', 'etapas', 'modelo', 'descripcion', 'pn', 'sn'])}
            {renderComponentFields('Pump Upper', 'fondo.pumpUpper', ['estado', 'serie', 'etapas', 'modelo', 'descripcion', 'pn', 'sn'])}
            {renderComponentFields('Intake/Separador de Gas', 'fondo.intakeSeparador', ['estado', 'serie', 'descripcion', 'pn', 'sn', 'profundidad'])}
          </div>
        );
      case 3:
        return (
          <div className="space-y-6">
            {renderComponentFields('Protector Superior', 'fondo.protectorSuperior', ['estado', 'serie', 'descripcion', 'pn', 'sn'])}
            {renderComponentFields('Protector Central', 'fondo.protectorCentral', ['estado', 'serie', 'descripcion', 'pn', 'sn'])}
            {renderComponentFields('Protector Inferior', 'fondo.protectorInferior', ['estado', 'serie', 'descripcion', 'pn', 'sn'])}
            {renderComponentFields('Motor UT', 'fondo.motorUT', ['estado', 'serie', 'descripcion', 'hp', 'vol', 'amp', 'pn', 'sn'])}
          </div>
        );
      case 4:
        return (
          <div className="space-y-6">
            {renderComponentFields('Motor CT', 'fondo.motorCT', ['estado', 'serie', 'descripcion', 'hp', 'vol', 'amp', 'pn', 'sn'])}
            {renderComponentFields('Motor LT', 'fondo.motorLT', ['estado', 'serie', 'descripcion', 'hp', 'vol', 'amp', 'pn', 'sn'])}
            <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
              <FormField label="Tecnología Motor (AM/PMM)" value={formData.fondo.tecMotor} onChange={v => handleChange('fondo.tecMotor', v)} />
            </div>
            {renderComponentFields('Sensor', 'fondo.sensor', ['estado', 'marca', 'descripcion', 'pn', 'sn'])}
          </div>
        );
      case 5:
        return (
          <div className="space-y-6">
            {renderComponentFields('MLE', 'cable.mle', ['descripcion', 'pn', 'sn', 'estado'])}
            {renderComponentFields('Cable Fondo', 'cable.cableFondo', ['pn', 'sn', 'longitud', 'awg', 'tipo', 'descripcion', 'estado2'])}
          </div>
        );
      case 6:
        return (
          <div className="space-y-6">
            {renderComponentFields('VSD', 'superficie.vsd', ['marca', 'descripcion', 'controlador', 'sn', 'pn', 'kva', 'ampOut', 'pulsos', 'origen'])}
            {renderComponentFields('Filtro Entrada', 'superficie.filter', ['sn', 'kva', 'descripcion'])}
            {renderComponentFields('SUT', 'superficie.sut', ['marca', 'sn', 'kva'])}
            {renderComponentFields('Y-Tool', 'yTool', ['serie', 'pn', 'sn'])}
            <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
              <FormField label="Detalles/Comentarios" value={formData.detalles} onChange={v => handleChange('detalles', v)} isTextArea />
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-3xl shadow-xl border border-black/5 overflow-hidden">
      <div className="flex border-b border-gray-100 overflow-x-auto no-scrollbar">
        {SECTIONS.map((section, index) => (
          <button
            key={section}
            onClick={() => setActiveSection(index)}
            className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${activeSection === index
                ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/50'
                : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
              }`}
          >
            {index + 1}. {section}
          </button>
        ))}
      </div>

      <div className="p-8">
        <form onSubmit={e => { e.preventDefault(); onSubmit(formData as ESPRecord); }}>
          <div className="min-h-[400px]">
            {renderSection()}
          </div>

          <div className="mt-12 flex items-center justify-between pt-8 border-t border-gray-100">
            <button
              type="button"
              disabled={activeSection === 0}
              onClick={() => setActiveSection(prev => prev - 1)}
              className="flex items-center px-6 py-3 text-sm font-medium text-gray-600 bg-gray-100 rounded-xl hover:bg-gray-200 disabled:opacity-50 transition-all"
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Anterior
            </button>

            {activeSection === SECTIONS.length - 1 ? (
              <button
                type="submit"
                className="flex items-center px-8 py-3 text-sm font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all transform hover:scale-105 active:scale-95"
              >
                <Save className="w-4 h-4 mr-2" />
                Guardar Registro
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setActiveSection(prev => prev + 1)}
                className="flex items-center px-8 py-3 text-sm font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all transform hover:scale-105 active:scale-95"
              >
                Siguiente
                <ChevronRight className="w-4 h-4 ml-2" />
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

const FormField: React.FC<{
  label: string;
  value: any;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  isTextArea?: boolean;
}> = ({ label, value, onChange, type = 'text', required, isTextArea }) => (
  <div className="flex flex-col space-y-1.5">
    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
      {label} {required && <span className="text-rose-500">*</span>}
    </label>
    {isTextArea ? (
      <textarea
        value={value || ''}
        onChange={e => onChange(e.target.value)}
        required={required}
        className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none min-h-[100px]"
      />
    ) : (
      <input
        type={type}
        value={value || ''}
        onChange={e => onChange(e.target.value)}
        required={required}
        className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none"
      />
    )}
  </div>
);

const FormSelect: React.FC<{
  label: string;
  value: any;
  options: string[];
  onChange: (v: string) => void;
  required?: boolean;
}> = ({ label, value, options, onChange, required }) => (
  <div className="flex flex-col space-y-1.5">
    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
      {label} {required && <span className="text-rose-500">*</span>}
    </label>
    <select
      value={value || ''}
      onChange={e => onChange(e.target.value)}
      required={required}
      className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none appearance-none cursor-pointer"
    >
      <option value="">Seleccione...</option>
      {options.map(opt => (
        <option key={opt} value={opt}>{opt}</option>
      ))}
    </select>
  </div>
);

const FormCheckbox: React.FC<{
  label: string;
  checked?: boolean;
  onChange: (v: boolean) => void;
}> = ({ label, checked, onChange }) => (
  <div className="flex items-center space-x-3 p-4 bg-gray-50 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-100 transition-all" onClick={() => onChange(!checked)}>
    <input
      type="checkbox"
      checked={checked || false}
      onChange={e => onChange(e.target.checked)}
      className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
    />
    <span className="text-sm font-bold text-gray-700 uppercase tracking-wider">{label}</span>
  </div>
);
