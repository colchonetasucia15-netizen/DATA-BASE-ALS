import React, { useState, useMemo } from 'react';
import { Search, Filter, Download, ChevronDown, ChevronUp, MoreHorizontal, Eye, Trash2, FileSpreadsheet, AlertCircle, Anchor, X } from 'lucide-react';
import { ESPRecord } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import * as XLSX from 'xlsx';

interface Props {
  records: ESPRecord[];
  onViewDetails: (record: ESPRecord) => void;
  onStatusUpdate: (
    recordId: string,
    newStatus: 'FALLADO' | 'PULLING' | 'OPERATIVO',
    pullingData?: {
      razonPulling: string;
      razonEspecificaPulling: string;
      fecha?: string;
      componentStatuses?: Record<string, string>;
    },
    fallaData?: { fecha?: string }
  ) => void;
  onDelete: (record: ESPRecord) => void;
}

export const InventoryList: React.FC<Props> = ({ records, onViewDetails, onStatusUpdate, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [providerFilter, setProviderFilter] = useState<string>('ALL');
  const [campoFilter, setCampoFilter] = useState<string>('ALL');
  const [kvaFilter, setKvaFilter] = useState<string>('ALL');
  const [alsFilter, setAlsFilter] = useState<string>('ALL');
  const [motorTypeFilter, setMotorTypeFilter] = useState<string>('ALL');
  const [sortConfig, setSortConfig] = useState<{ key: keyof ESPRecord | string; direction: 'asc' | 'desc' } | null>(null);
  const [visibleCount, setVisibleCount] = useState(50);
  const loaderRef = React.useRef<HTMLDivElement>(null);

  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [advancedFilters, setAdvancedFilters] = useState<Record<string, string>>({});

  // Reset visible count when filters change to improve performance
  React.useEffect(() => {
    setVisibleCount(50);
  }, [searchTerm, statusFilter, providerFilter, campoFilter, kvaFilter, alsFilter, motorTypeFilter, advancedFilters]);

  // Confirmation/Pulling Modal State
  const [confirmModal, setConfirmModal] = useState<{
    show: boolean;
    type: 'FALLADO' | 'PULLING' | 'OPERATIVO' | 'DELETE';
    recordId: string;
    pozo: string;
  } | null>(null);

  const initialPullingForm = {
    razonPulling: '',
    razonEspecificaPulling: '',
    fecha: new Date().toISOString().split('T')[0],
    componentStatuses: {
      'BOMBAS': '',
      'INTAKE': '',
      'PROTECTOR': '',
      'MOTOR': '',
      'SENSOR': '',
      'CABLE': '',
      'VSD': ''
    }
  };

  const [pullingForm, setPullingForm] = useState(initialPullingForm);

  const [fallaForm, setFallaForm] = useState({
    fecha: new Date().toISOString().split('T')[0]
  });

  const providers = useMemo(() => {
    const p = new Set(records.map(r => r.proveedor).filter(Boolean));
    return ['ALL', ...Array.from(p)];
  }, [records]);

  const campos = useMemo(() => {
    const c = new Set(records.map(r => r.campo).filter(Boolean));
    return ['ALL', ...Array.from(c)];
  }, [records]);

  const kvas = useMemo(() => {
    const k = new Set(records.map(r => r.superficie.vsd.kva).filter(Boolean));
    return ['ALL', ...Array.from(k)];
  }, [records]);

  const alsOptions = useMemo(() => {
    const a = new Set(records.map(r => r.als).filter(Boolean));
    return ['ALL', ...Array.from(a)];
  }, [records]);

  const motorTypes = useMemo(() => {
    const types = new Set<string>();
    records.forEach(r => {
      if (r.nick) {
        const nick = r.nick.toUpperCase();
        if (nick.includes('PMM')) types.add('PMM');
        if (nick.includes('AM')) types.add('AM');
      }
      if (r.fondo.tecMotor) {
        types.add(r.fondo.tecMotor.toUpperCase());
      }
    });
    return ['ALL', ...Array.from(types)];
  }, [records]);

  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch =
        (r.pozo || '').toLowerCase().includes(searchLower) ||
        (r.nick || '').toLowerCase().includes(searchLower) ||
        (r.proveedor || '').toLowerCase().includes(searchLower) ||
        (r.campo || '').toLowerCase().includes(searchLower) ||
        (r.activo || '').toLowerCase().includes(searchLower) ||
        (r.bloque || '').toLowerCase().includes(searchLower) ||
        (r.superficie?.vsd?.serie || '').toLowerCase().includes(searchLower) ||
        (r.fondo?.motorUT?.serie || '').toLowerCase().includes(searchLower);

      const matchesStatus = statusFilter === 'ALL' || r.estadoInventario === statusFilter;
      const matchesProvider = providerFilter === 'ALL' || r.proveedor === providerFilter;
      const matchesCampo = campoFilter === 'ALL' || r.campo === campoFilter;
      const matchesKva = kvaFilter === 'ALL' || r.superficie?.vsd?.kva === kvaFilter;
      const matchesAls = alsFilter === 'ALL' || r.als === alsFilter;

      const motorType = ((r.nick || '') + ' ' + (r.fondo?.tecMotor || '')).toUpperCase();
      const matchesMotorType = motorTypeFilter === 'ALL' || motorType.includes(motorTypeFilter);

      // Advanced Filters Logic
      const matchesAdvanced = Object.entries(advancedFilters).every(([key, value]) => {
        if (!value || value === 'ALL') return true;

        let recordValue = '';
        switch (key) {
          case 'Pozo': recordValue = r.pozo; break;
          case 'Nick': recordValue = r.nick; break;
          case 'Proveedor': recordValue = r.proveedor; break;
          case 'Estado': recordValue = r.estadoInventario; break;
          case 'ALS': recordValue = r.als; break;
          case 'Run Life': recordValue = String(r.runLife); break;
          case 'Fecha Run': recordValue = r.fechaRun; break;
          case 'Campo': recordValue = r.campo; break;
          case 'Bloque': recordValue = r.bloque; break;
          case 'Activo': recordValue = r.activo; break;
          case 'Cluster': recordValue = r.cluster; break;
          case 'VSD KVA': recordValue = r.superficie?.vsd?.kva || ''; break;
          case 'HP Motor': recordValue = r.fondo?.motorUT?.hp || ''; break;
          case 'VSD Origen': recordValue = r.superficie?.vsd?.origen || ''; break;
          case 'Estado Cable 2': recordValue = r.cable?.cableFondo?.estado2 || ''; break;
          case 'Serie VSD': recordValue = r.superficie?.vsd?.serie || ''; break;
          case 'Serie Motor': recordValue = r.fondo?.motorUT?.serie || ''; break;
          case 'Serie SUT': recordValue = r.superficie?.sut?.serie || ''; break;
          case 'Serie Filtro': recordValue = r.superficie?.filter?.serie || ''; break;
          case 'Fecha Falla': recordValue = r.fechaFalla || ''; break;
          case 'Fecha Pulling': recordValue = r.fechaPull || ''; break;
          default: return true;
        }
        return (recordValue || '').toLowerCase().includes((value as string).toLowerCase());
      });

      return matchesSearch && matchesStatus && matchesProvider && matchesCampo && matchesKva && matchesAls && matchesMotorType && matchesAdvanced;
    }).sort((a, b) => {
      if (!sortConfig) return 0;
      const { key, direction } = sortConfig;

      let aVal: any = a[key as keyof ESPRecord];
      let bVal: any = b[key as keyof ESPRecord];

      if (key === 'vsd_kva') {
        aVal = a.superficie.vsd.kva || '';
        bVal = b.superficie.vsd.kva || '';
      }

      if (aVal < bVal) return direction === 'asc' ? -1 : 1;
      if (aVal > bVal) return direction === 'asc' ? 1 : -1;
      return 0;
    });
  }, [records, searchTerm, statusFilter, providerFilter, campoFilter, kvaFilter, alsFilter, motorTypeFilter, advancedFilters, sortConfig]);

  // Infinite Scroll Implementation
  React.useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && filteredRecords.length > visibleCount) {
          setVisibleCount(prev => prev + 50);
        }
      },
      { threshold: 0.1 }
    );

    if (loaderRef.current) {
      observer.observe(loaderRef.current);
    }

    return () => observer.disconnect();
  }, [filteredRecords.length, visibleCount]);

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const exportToExcel = () => {
    const data = filteredRecords.map(r => ({
      Pozo: r.pozo,
      Nick: r.nick,
      Proveedor: r.proveedor,
      Estado: r.estadoInventario,
      'Run Life (Días)': r.runLife,
      'Fecha Run': r.fechaRun,
      Campo: r.campo,
      Bloque: r.bloque,
      'VSD KVA': r.superficie.vsd.kva,
      'HP Motor': r.fondo.motorUT.hp,
      'VSD Origen': r.superficie.vsd.origen || '',
      'Estado Post-Pull BOMBAS': r.fondo.pumpLower.estadoPostPull || '',
      'Estado Post-Pull INTAKE': r.fondo.intakeSeparador.estadoPostPull || '',
      'Estado Post-Pull PROTECTOR': r.fondo.protectorSuperior.estadoPostPull || '',
      'Estado Post-Pull MOTOR': r.fondo.motorUT.estadoPostPull || '',
      'Estado Post-Pull SENSOR': r.fondo.sensor.estadoPostPull || '',
      'Estado Post-Pull CABLE': r.cable.cableFondo.estadoPostPull || '',
      'Estado Post-Pull VSD': r.superficie.vsd.estadoPostPull || '',
      'Estado Postpulling PUMP': r.fondo.pumpLower.estadoPostPull || '',
      'Estado Postpulling INTAKE': r.fondo.intakeSeparador.estadoPostPull || '',
      'Estado Postpulling PROTECTOR': r.fondo.protectorSuperior.estadoPostPull || '',
      'Estado Postpulling MOTOR': r.fondo.motorUT.estadoPostPull || '',
      'Estado Postpulling SENSOR': r.fondo.sensor.estadoPostPull || '',
      'Estado Postpulling CABLE': r.cable.cableFondo.estadoPostPull || ''
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Inventario");
    XLSX.writeFile(wb, "Inventario_ESP.xlsx");
  };

  const excelColumns = [
    'Pozo', 'Nick', 'Proveedor', 'Estado', 'ALS', 'Run Life', 'Fecha Run', 'Fecha Falla', 'Fecha Pulling',
    'Campo', 'Bloque', 'Activo', 'Cluster', 'VSD KVA', 'HP Motor', 'VSD Origen',
    'Estado Cable 2', 'Serie VSD', 'Serie Motor', 'Serie SUT', 'Serie Filtro'
  ];

  return (
    <div className="bg-white rounded-[2.5rem] shadow-xl border border-black/5 overflow-hidden flex flex-col h-full">
      {/* Filters Header */}
      <div className="p-4 border-b border-gray-100 bg-gray-50/30 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar por Pozo, Nick, Proveedor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-11 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-xs"
            />
          </div>
          <div className="flex items-center space-x-2">
            {(searchTerm || statusFilter !== 'ALL' || providerFilter !== 'ALL' || campoFilter !== 'ALL' || kvaFilter !== 'ALL' || alsFilter !== 'ALL' || motorTypeFilter !== 'ALL' || Object.keys(advancedFilters).length > 0) && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setStatusFilter('ALL');
                  setProviderFilter('ALL');
                  setCampoFilter('ALL');
                  setKvaFilter('ALL');
                  setAlsFilter('ALL');
                  setMotorTypeFilter('ALL');
                  setAdvancedFilters({});
                }}
                className="px-3 py-2.5 text-rose-600 hover:bg-rose-50 rounded-xl transition-colors text-[10px] font-black uppercase tracking-widest"
              >
                Limpiar
              </button>
            )}
            <button
              onClick={() => setShowAdvancedFilters(true)}
              className="flex items-center px-4 py-2.5 bg-blue-50 text-blue-700 font-bold rounded-xl border border-blue-100 hover:bg-blue-100 transition-all text-xs"
            >
              <Filter className="w-3.5 h-3.5 mr-2" />
              Filtros
            </button>
            <button
              onClick={exportToExcel}
              className="flex items-center px-4 py-2.5 bg-emerald-50 text-emerald-700 font-bold rounded-xl border border-emerald-100 hover:bg-emerald-100 transition-all text-xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 mr-2" />
              Excel
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
          <div className="flex flex-col space-y-1">
            <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-1">Estado</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded-lg text-[10px] font-bold focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="ALL">TODOS</option>
              <option value="OPERATIVO">OPERATIVO</option>
              <option value="FALLADO">FALLADO</option>
              <option value="PULLING">PULLING</option>
            </select>
          </div>

          <div className="flex flex-col space-y-1">
            <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-1">Proveedor</label>
            <select
              value={providerFilter}
              onChange={(e) => setProviderFilter(e.target.value)}
              className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded-lg text-[10px] font-bold focus:ring-2 focus:ring-blue-500 outline-none"
            >
              {providers.map(p => (
                <option key={p} value={p}>{p === 'ALL' ? 'TODOS' : p}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col space-y-1">
            <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-1">Campo</label>
            <select
              value={campoFilter}
              onChange={(e) => setCampoFilter(e.target.value)}
              className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded-lg text-[10px] font-bold focus:ring-2 focus:ring-blue-500 outline-none"
            >
              {campos.map(c => (
                <option key={c} value={c}>{c === 'ALL' ? 'TODOS' : c}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col space-y-1">
            <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-1">VSD KVA</label>
            <select
              value={kvaFilter}
              onChange={(e) => setKvaFilter(e.target.value)}
              className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded-lg text-[10px] font-bold focus:ring-2 focus:ring-blue-500 outline-none"
            >
              {kvas.map(k => (
                <option key={k} value={k}>{k === 'ALL' ? 'TODOS' : k}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col space-y-1">
            <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-1">ALS</label>
            <select
              value={alsFilter}
              onChange={(e) => setAlsFilter(e.target.value)}
              className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded-lg text-[10px] font-bold focus:ring-2 focus:ring-blue-500 outline-none"
            >
              {alsOptions.map(a => (
                <option key={a} value={a}>{a === 'ALL' ? 'TODOS' : a}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col space-y-1">
            <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-1">Tipo Motor</label>
            <select
              value={motorTypeFilter}
              onChange={(e) => setMotorTypeFilter(e.target.value)}
              className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded-lg text-[10px] font-bold focus:ring-2 focus:ring-blue-500 outline-none"
            >
              {motorTypes.map(t => (
                <option key={t} value={t}>{t === 'ALL' ? 'TODOS' : t}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-left border-collapse">
          <thead className="sticky top-0 z-10 bg-white/80 backdrop-blur-md shadow-sm border-b border-gray-100">
            <tr>
              <th onClick={() => handleSort('pozo')} className="px-3 py-2.5 text-[9px] font-black text-gray-400 uppercase tracking-widest cursor-pointer hover:text-blue-600 transition-colors">
                <div className="flex items-center">
                  Pozo {sortConfig?.key === 'pozo' && (sortConfig.direction === 'asc' ? <ChevronUp className="w-3 h-3 ml-1 text-blue-600" /> : <ChevronDown className="w-3 h-3 ml-1 text-blue-600" />)}
                </div>
              </th>
              <th onClick={() => handleSort('proveedor')} className="px-3 py-2.5 text-[9px] font-black text-gray-400 uppercase tracking-widest cursor-pointer hover:text-blue-600 transition-colors">
                <div className="flex items-center">
                  Proveedor {sortConfig?.key === 'proveedor' && (sortConfig.direction === 'asc' ? <ChevronUp className="w-3 h-3 ml-1 text-blue-600" /> : <ChevronDown className="w-3 h-3 ml-1 text-blue-600" />)}
                </div>
              </th>
              <th onClick={() => handleSort('estadoInventario')} className="px-3 py-2.5 text-[9px] font-black text-gray-400 uppercase tracking-widest cursor-pointer hover:text-blue-600 transition-colors">
                <div className="flex items-center">
                  Estado {sortConfig?.key === 'estadoInventario' && (sortConfig.direction === 'asc' ? <ChevronUp className="w-3 h-3 ml-1 text-blue-600" /> : <ChevronDown className="w-3 h-3 ml-1 text-blue-600" />)}
                </div>
              </th>
              <th onClick={() => handleSort('als')} className="px-3 py-2.5 text-[9px] font-black text-gray-400 uppercase tracking-widest cursor-pointer hover:text-blue-600 transition-colors">
                <div className="flex items-center">
                  ALS {sortConfig?.key === 'als' && (sortConfig.direction === 'asc' ? <ChevronUp className="w-3 h-3 ml-1 text-blue-600" /> : <ChevronDown className="w-3 h-3 ml-1 text-blue-600" />)}
                </div>
              </th>
              <th onClick={() => handleSort('vsd_kva')} className="px-3 py-2.5 text-[9px] font-black text-gray-400 uppercase tracking-widest cursor-pointer hover:text-blue-600 transition-colors">
                <div className="flex items-center">
                  VSD KVA {sortConfig?.key === 'vsd_kva' && (sortConfig.direction === 'asc' ? <ChevronUp className="w-3 h-3 ml-1 text-blue-600" /> : <ChevronDown className="w-3 h-3 ml-1 text-blue-600" />)}
                </div>
              </th>
              <th onClick={() => handleSort('runLife')} className="px-3 py-2.5 text-[9px] font-black text-gray-400 uppercase tracking-widest cursor-pointer hover:text-blue-600 transition-colors">
                <div className="flex items-center">
                  Run Life {sortConfig?.key === 'runLife' && (sortConfig.direction === 'asc' ? <ChevronUp className="w-3 h-3 ml-1 text-blue-600" /> : <ChevronDown className="w-3 h-3 ml-1 text-blue-600" />)}
                </div>
              </th>
              <th className="px-3 py-2.5 text-[9px] font-black text-gray-400 uppercase tracking-widest text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filteredRecords.slice(0, visibleCount).map((record, idx) => (
              <tr
                key={record.id}
                className="group hover:bg-blue-50/40 transition-all cursor-default"
              >
                <td className="px-3 py-1.5">
                  <div className="flex flex-col">
                    <div className="flex items-center space-x-2">
                      <span className="font-black text-gray-900 group-hover:text-blue-700 transition-colors text-[11px]">{record.pozo}</span>
                      {[
                        record.fondo?.pumpLower,
                        record.fondo?.pumpUpper,
                        record.fondo?.intake,
                        record.fondo?.protectorLower,
                        record.fondo?.protectorUpper,
                        record.fondo?.motorLower,
                        record.fondo?.motorUpper,
                        record.fondo?.sensor,
                        record.superficie?.cable,
                        record.superficie?.vsd
                      ].some(c => c?.estadoPostPull === 'PENDIENTE') && (
                        <span className="px-1 py-0.5 bg-orange-100 text-orange-700 text-[6px] font-black rounded border border-orange-200 animate-pulse">
                          PENDIENTE
                        </span>
                      )}
                    </div>
                    <span className="text-[8px] font-bold text-gray-400 uppercase tracking-tighter leading-none">{record.nick}</span>
                  </div>
                </td>
                <td className="px-3 py-1.5">
                  <span className="text-[9px] font-bold text-gray-600 bg-gray-100/80 px-1.5 py-0.5 rounded border border-gray-200/50">{record.proveedor}</span>
                </td>
                <td className="px-3 py-1.5">
                  <span className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider ${record.estadoInventario === 'OPERATIVO' ? 'bg-emerald-100 text-emerald-700' :
                    record.estadoInventario === 'FALLADO' ? 'bg-rose-100 text-rose-700' :
                      'bg-amber-100 text-amber-700'
                    }`}>
                    <div className={`w-1 h-1 rounded-full mr-1 ${record.estadoInventario === 'OPERATIVO' ? 'bg-emerald-500 animate-pulse' :
                      record.estadoInventario === 'FALLADO' ? 'bg-rose-500' :
                        'bg-amber-500'
                      }`} />
                    {record.estadoInventario}
                  </span>
                </td>
                <td className="px-3 py-1.5">
                  <span className="text-[9px] font-black text-blue-600 bg-blue-50/80 px-1.5 py-0.5 rounded border border-blue-100/50">
                    {record.als || 'ESP'}
                  </span>
                </td>
                <td className="px-3 py-1.5">
                  <div className="flex items-center space-x-1">
                    <span className="text-[11px] font-black text-gray-900">{record.superficie?.vsd?.kva || '-'}</span>
                    <span className="text-[8px] font-bold text-gray-400">KVA</span>
                  </div>
                </td>
                <td className="px-3 py-1.5">
                  <div className="flex flex-col">
                    <div className="flex items-center space-x-1">
                      <span className="text-[11px] font-black text-gray-900">{record.runLife}</span>
                      <span className="text-[8px] font-bold text-gray-400 uppercase">días</span>
                    </div>
                    <div className="w-12 h-0.5 bg-gray-100 rounded-full mt-0.5 overflow-hidden">
                      <div
                        style={{ width: `${Math.min(100, (record.runLife / 1000) * 100)}%` }}
                        className={`h-full rounded-full ${record.runLife > 365 ? 'bg-emerald-500' : record.runLife > 180 ? 'bg-blue-500' : 'bg-amber-500'}`}
                      />
                    </div>
                  </div>
                </td>
                <td className="px-3 py-1.5 text-right">
                  <div className="flex items-center justify-end space-x-1 opacity-0 group-hover:opacity-100 transition-all">
                    {record.estadoInventario !== 'FALLADO' && (
                      <button
                        onClick={() => setConfirmModal({ show: true, type: 'FALLADO', recordId: record.id!, pozo: record.pozo })}
                        className="p-1 bg-white text-rose-600 rounded-lg hover:bg-rose-600 hover:text-white shadow-sm border border-rose-100 transition-all active:scale-90"
                        title="Marcar como Falla"
                      >
                        <AlertCircle className="w-3 h-3" />
                      </button>
                    )}
                    {record.estadoInventario !== 'PULLING' && (
                      <button
                        onClick={() => setConfirmModal({ show: true, type: 'PULLING', recordId: record.id!, pozo: record.pozo })}
                        className="p-1 bg-white text-amber-600 rounded-lg hover:bg-amber-600 hover:text-white shadow-sm border border-amber-100 transition-all active:scale-90"
                        title="Marcar como Pulling"
                      >
                        <Anchor className="w-3 h-3" />
                      </button>
                    )}
                    <button
                      onClick={() => onViewDetails(record)}
                      className="p-1 bg-white text-blue-600 rounded-lg hover:bg-blue-600 hover:text-white shadow-sm border border-blue-100 transition-all active:scale-90"
                      title="Ver Detalles"
                    >
                      <Eye className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => setConfirmModal({ show: true, type: 'DELETE', recordId: record.id!, pozo: record.pozo })}
                      className="p-1 bg-white text-gray-400 rounded-lg hover:bg-rose-600 hover:text-white shadow-sm border border-gray-100 hover:border-rose-100 transition-all active:scale-90"
                      title="Eliminar"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {filteredRecords.length > visibleCount && (
              <tr>
                <td colSpan={7} className="px-6 py-8 text-center">
                  <div ref={loaderRef} className="flex flex-col items-center justify-center space-y-2">
                    <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Cargando más registros...</span>
                  </div>
                </td>
              </tr>
            )}
            {filteredRecords.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-20 text-center">
                  <div className="flex flex-col items-center justify-center text-gray-400">
                    <Search className="w-12 h-12 mb-4 opacity-20" />
                    <p className="text-sm font-medium">No se encontraron registros que coincidan con los filtros</p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Footer Info */}
      <div className="p-3 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
        <span className="text-[10px] text-gray-400 font-medium">
          Mostrando <strong>{filteredRecords.length}</strong> de <strong>{records.length}</strong> registros
        </span>
        <div className="flex items-center space-x-2">
          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
          <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Base de Datos Local</span>
        </div>
      </div>
      {/* Confirmation Modal */}
      <AnimatePresence>
        {confirmModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className={`bg-white rounded-[2.5rem] shadow-2xl border border-gray-100 w-full overflow-hidden ${confirmModal.type === 'PULLING' ? 'max-w-xl' : 'max-w-md'}`}
            >
              <div className={`p-5 flex items-center space-x-4 ${confirmModal.type === 'FALLADO' || confirmModal.type === 'DELETE' ? 'bg-rose-50' : 'bg-amber-50'}`}>
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${confirmModal.type === 'FALLADO' || confirmModal.type === 'DELETE' ? 'bg-rose-100 text-rose-600' : 'bg-amber-100 text-amber-600'}`}>
                  {confirmModal.type === 'FALLADO' ? <AlertCircle className="w-5 h-5" /> :
                    confirmModal.type === 'DELETE' ? <Trash2 className="w-5 h-5" /> :
                      <Anchor className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="text-base font-black text-gray-900 uppercase tracking-tighter">
                    {confirmModal.type === 'DELETE' ? 'Eliminar Registro' : 
                     confirmModal.type === 'PULLING' ? 'Reportar Extracción (Pulling)' : 
                     'Reportar Falla'}
                  </h3>
                  <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest leading-none">Pozo: {confirmModal.pozo}</p>
                </div>
              </div>

              <div className="p-6 max-h-[70vh] overflow-y-auto">
                <p className="text-gray-500 text-xs mb-5">
                  {confirmModal.type === 'DELETE'
                    ? `¿Estás seguro de que deseas eliminar permanentemente el registro del pozo ${confirmModal.pozo}? Esta acción no se puede deshacer.`
                    : confirmModal.type === 'PULLING'
                    ? `Complete la información técnica para la extracción del equipo en el pozo ${confirmModal.pozo}.`
                    : `Confirme la fecha de falla detectada para el pozo ${confirmModal.pozo}.`
                  }
                </p>

                {confirmModal.type === 'PULLING' && (
                  <div className="space-y-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1 block ml-1">Fecha de Pulling</label>
                        <input
                          type="date"
                          value={pullingForm.fecha}
                          onChange={(e) => setPullingForm(prev => ({ ...prev, fecha: e.target.value }))}
                          className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none transition-all text-[10px] font-bold"
                        />
                      </div>
                      <div>
                        <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1 block ml-1">Razón de Pulling</label>
                        <input
                          type="text"
                          value={pullingForm.razonPulling}
                          onChange={(e) => setPullingForm(prev => ({ ...prev, razonPulling: e.target.value }))}
                          placeholder="Ej: Falla Eléctrica..."
                          className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none transition-all text-[10px] font-bold"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1 block ml-1">Razón Específica / Comentarios</label>
                      <textarea
                        value={pullingForm.razonEspecificaPulling}
                        onChange={(e) => setPullingForm(prev => ({ ...prev, razonEspecificaPulling: e.target.value }))}
                        placeholder="Detalles adicionales sobre la extracción..."
                        className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none transition-all text-[10px] font-bold h-16 resize-none"
                      />
                    </div>

                    <div className="pt-4 border-t border-gray-100">
                      <h4 className="text-[9px] font-black text-amber-600 uppercase tracking-widest mb-3 flex items-center">
                        <div className="w-1.5 h-1.5 bg-amber-500 rounded-full mr-2" />
                        Estatus de Equipos Post-Pulling
                      </h4>

                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {['BOMBAS', 'INTAKE', 'PROTECTOR', 'MOTOR', 'SENSOR', 'CABLE', 'VSD'].map((comp) => (
                          <div key={comp} className="flex flex-col space-y-0.5 bg-gray-50/50 p-1.5 rounded-lg border border-gray-100">
                            <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest ml-1">{comp}</span>
                            <select
                              value={pullingForm.componentStatuses[comp]}
                              onChange={(e) => setPullingForm(prev => ({
                                ...prev,
                                componentStatuses: { ...prev.componentStatuses, [comp]: e.target.value }
                              }))}
                              className="bg-white border border-gray-200 rounded-md text-[9px] font-bold px-1.5 py-1 focus:ring-2 focus:ring-amber-500 outline-none"
                            >
                              <option value="">SELECCIONAR...</option>
                              <option value="PENDIENTE">PENDIENTE</option>
                              <option value="REPARACIÓN">REPARACIÓN</option>
                              <option value="REMANUFACTURA">REMANUFACTURA</option>
                              <option value="INSPECCIÓN">INSPECCIÓN</option>
                              <option value="PERDIDO">PERDIDO</option>
                              <option value="BUENO PARA USAR">BUENO PARA USAR</option>
                              <option value="SCRAP">SCRAP</option>
                            </select>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {confirmModal.type === 'FALLADO' && (
                  <div className="space-y-4">
                    <div>
                      <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1 block ml-1">Fecha de Falla</label>
                      <input
                        type="date"
                        value={fallaForm.fecha}
                        onChange={(e) => setFallaForm(prev => ({ ...prev, fecha: e.target.value }))}
                        className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-rose-500 outline-none transition-all text-[10px] font-bold"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="p-5 bg-gray-50 flex items-center space-x-3 border-t border-gray-100">
                <button
                  onClick={() => {
                    setConfirmModal(null);
                    setPullingForm(initialPullingForm);
                  }}
                  className="flex-1 px-4 py-2 bg-white border border-gray-200 text-gray-600 rounded-xl font-bold hover:bg-gray-50 transition-all text-xs"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => {
                    if (confirmModal.type === 'PULLING') {
                      onStatusUpdate(confirmModal.recordId, 'PULLING', pullingForm);
                    } else if (confirmModal.type === 'FALLADO') {
                      onStatusUpdate(confirmModal.recordId, 'FALLADO', undefined, fallaForm);
                    } else if (confirmModal.type === 'DELETE') {
                      const record = records.find(r => r.id === confirmModal.recordId);
                      if (record) onDelete(record);
                    }
                    setConfirmModal(null);
                    setPullingForm(initialPullingForm);
                    setFallaForm({
                      fecha: new Date().toISOString().split('T')[0]
                    });
                  }}
                  className={`flex-1 px-4 py-2 text-white rounded-xl font-bold shadow-lg transition-all active:scale-95 text-xs ${
                    confirmModal.type === 'FALLADO' || confirmModal.type === 'DELETE' 
                      ? 'bg-rose-600 shadow-rose-100 hover:bg-rose-700' 
                      : 'bg-amber-600 shadow-amber-100 hover:bg-amber-700'
                  }`}
                >
                  {confirmModal.type === 'DELETE' ? 'Eliminar Definitivamente' : 'Confirmar Reporte'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Advanced Filters Modal */}
      <AnimatePresence>
        {showAdvancedFilters && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-blue-50/50">
                <div className="flex items-center space-x-3">
                  <div className="bg-blue-600 p-1.5 rounded-lg">
                    <Filter className="w-4 h-4 text-white" />
                  </div>
                  <h3 className="text-base font-black text-gray-900 uppercase tracking-tighter">Filtros Avanzados</h3>
                </div>
                <button
                  onClick={() => setShowAdvancedFilters(false)}
                  className="p-1.5 hover:bg-white rounded-full transition-colors group"
                >
                  <X className="w-5 h-5 text-gray-400 group-hover:text-gray-600" />
                </button>
              </div>

              <div className="p-5 max-h-[60vh] overflow-y-auto">
                <div className="space-y-5">
                  {/* Group: General Information */}
                  <div className="space-y-2">
                    <h4 className="text-[9px] font-black text-blue-600 uppercase tracking-[0.2em] border-b border-blue-100 pb-1.5">Información General</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {['Pozo', 'Nick', 'Proveedor', 'Estado', 'ALS', 'Campo', 'Bloque', 'Activo', 'Cluster'].map(col => (
                        <div key={col} className="space-y-0.5">
                          <label className="text-[8px] font-black text-gray-400 uppercase tracking-widest ml-1">{col}</label>
                          {['Estado', 'ALS', 'Proveedor', 'Campo'].includes(col) ? (
                            <select
                              value={advancedFilters[col] || 'ALL'}
                              onChange={(e) => setAdvancedFilters(prev => ({ ...prev, [col]: e.target.value }))}
                              className="w-full px-2 py-1.5 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all text-[10px] font-bold"
                            >
                              {(col === 'Estado' ? ['ALL', 'OPERATIVO', 'FALLADO', 'PULLING'] :
                                col === 'ALS' ? alsOptions :
                                  col === 'Proveedor' ? providers :
                                    campos).map(opt => (
                                      <option key={opt} value={opt}>{opt === 'ALL' ? `TODOS` : opt}</option>
                                    ))}
                            </select>
                          ) : (
                            <input
                              type="text"
                              placeholder={`${col}...`}
                              value={advancedFilters[col] || ''}
                              onChange={(e) => setAdvancedFilters(prev => ({ ...prev, [col]: e.target.value }))}
                              className="w-full px-2 py-1.5 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all text-[10px] font-bold"
                            />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Group: Technical Data */}
                  <div className="space-y-2">
                    <h4 className="text-[9px] font-black text-emerald-600 uppercase tracking-[0.2em] border-b border-emerald-100 pb-1.5">Datos Técnicos</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {['VSD KVA', 'HP Motor', 'VSD Origen', 'Estado Cable 2', 'Serie VSD', 'Serie Motor', 'Serie SUT', 'Serie Filtro'].map(col => (
                        <div key={col} className="space-y-0.5">
                          <label className="text-[8px] font-black text-gray-400 uppercase tracking-widest ml-1">{col}</label>
                          <input
                            type="text"
                            placeholder={`${col}...`}
                            value={advancedFilters[col] || ''}
                            onChange={(e) => setAdvancedFilters(prev => ({ ...prev, [col]: e.target.value }))}
                            className="w-full px-2 py-1.5 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none transition-all text-[10px] font-bold"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Group: Dates & Performance */}
                  <div className="space-y-2">
                    <h4 className="text-[9px] font-black text-amber-600 uppercase tracking-[0.2em] border-b border-amber-100 pb-1.5">Fechas y Rendimiento</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {['Run Life', 'Fecha Run', 'Fecha Falla', 'Fecha Pulling'].map(col => (
                        <div key={col} className="space-y-0.5">
                          <label className="text-[8px] font-black text-gray-400 uppercase tracking-widest ml-1">{col}</label>
                          <input
                            type={col.includes('Fecha') ? 'date' : 'text'}
                            placeholder={`${col}...`}
                            value={advancedFilters[col] || ''}
                            onChange={(e) => setAdvancedFilters(prev => ({ ...prev, [col]: e.target.value }))}
                            className="w-full px-2 py-1.5 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none transition-all text-[10px] font-bold"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-gray-50 flex items-center justify-between border-t border-gray-100">
                <button
                  onClick={() => setAdvancedFilters({})}
                  className="px-4 py-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-colors text-[10px] font-black uppercase tracking-widest"
                >
                  Limpiar Filtros
                </button>
                <button
                  onClick={() => setShowAdvancedFilters(false)}
                  className="px-8 py-2 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-100 transition-all active:scale-95 text-xs"
                >
                  Aplicar Filtros
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
