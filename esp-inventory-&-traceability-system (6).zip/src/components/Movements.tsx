import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRightLeft, 
  Box, 
  Zap, 
  Search, 
  AlertCircle, 
  CheckCircle2,
  Anchor,
  ArrowRight,
  Database,
  Truck,
  ChevronDown
} from 'lucide-react';
import { ESPRecord } from '../types';

interface Props {
  records: ESPRecord[];
  onMoveSkid: (sourceId: string, targetId: string) => Promise<void>;
}

export const Movements: React.FC<Props> = ({ records, onMoveSkid }) => {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Skid Movement State
  const [sourcePozo, setSourcePozo] = useState('');
  const [targetPozo, setTargetPozo] = useState('');
  const [sourceSearch, setSourceSearch] = useState('');
  const [targetSearch, setTargetSearch] = useState('');

  const wellsWithSkid = useMemo(() => 
    records.filter(r => r.superficie?.vsd?.serie || r.superficie?.filter?.serie || r.superficie?.sut?.serie),
    [records]
  );

  const filteredSourceOptions = useMemo(() => {
    const options = [{ id: 'BASE', pozo: 'BASE', campo: 'BODEGA' }, ...wellsWithSkid];
    return options.filter(o => 
      o.pozo.toLowerCase().includes(sourceSearch.toLowerCase()) || 
      o.campo.toLowerCase().includes(sourceSearch.toLowerCase())
    );
  }, [wellsWithSkid, sourceSearch]);

  const filteredTargetOptions = useMemo(() => {
    const options = [{ id: 'BASE', pozo: 'BASE', campo: 'BODEGA' }, ...records];
    return options.filter(o => 
      o.pozo.toLowerCase().includes(targetSearch.toLowerCase()) || 
      o.campo.toLowerCase().includes(targetSearch.toLowerCase())
    );
  }, [records, targetSearch]);

  const handleSkidMove = async () => {
    if (!sourcePozo || !targetPozo) {
      setError('Debe seleccionar origen y destino');
      return;
    }
    if (sourcePozo === targetPozo) {
      setError('El origen y destino no pueden ser iguales');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await onMoveSkid(sourcePozo, targetPozo);
      setSuccess('Movimiento de Skid realizado con éxito');
      setSourcePozo('');
      setTargetPozo('');
      setSourceSearch('');
      setTargetSearch('');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError('Error al realizar el movimiento');
    } finally {
      setLoading(false);
    }
  };

  const SearchableDropdown = ({ 
    label, 
    value, 
    onChange, 
    search, 
    onSearchChange, 
    options, 
    placeholder 
  }: { 
    label: string, 
    value: string, 
    onChange: (val: string) => void, 
    search: string, 
    onSearchChange: (val: string) => void, 
    options: any[], 
    placeholder: string 
  }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
      <div className="space-y-2 relative">
        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">{label}</label>
        <div className="relative">
          <div 
            onClick={() => setIsOpen(!isOpen)}
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus-within:ring-2 focus-within:ring-blue-500 outline-none transition-all flex items-center justify-between cursor-pointer"
          >
            <span className={`text-sm font-bold ${value ? 'text-gray-900' : 'text-gray-400'}`}>
              {value ? options.find(o => o.pozo === value)?.pozo || value : placeholder}
            </span>
            <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
          </div>

          <AnimatePresence>
            {isOpen && (
              <>
                <div 
                  className="fixed inset-0 z-10" 
                  onClick={() => setIsOpen(false)} 
                />
                <motion.div 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute z-20 top-full left-0 right-0 mt-2 bg-white border border-gray-100 shadow-xl rounded-2xl overflow-hidden"
                >
                  <div className="p-2 border-b border-gray-50">
                    <div className="relative">
                      <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                      <input 
                        type="text"
                        autoFocus
                        placeholder="Buscar..."
                        value={search}
                        onChange={(e) => onSearchChange(e.target.value)}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full pl-9 pr-4 py-2 bg-gray-50 border-none rounded-xl text-xs font-bold focus:ring-0 outline-none"
                      />
                    </div>
                  </div>
                  <div className="max-h-60 overflow-y-auto p-1">
                    {options.length > 0 ? (
                      options.map(o => (
                        <div 
                          key={o.id}
                          onClick={() => {
                            onChange(o.pozo);
                            setIsOpen(false);
                          }}
                          className={`px-4 py-2.5 rounded-xl text-sm font-bold cursor-pointer transition-colors ${
                            value === o.pozo ? 'bg-blue-50 text-blue-700' : 'hover:bg-gray-50 text-gray-700'
                          }`}
                        >
                          <div className="flex flex-col">
                            <span>{o.pozo}</span>
                            <span className="text-[10px] font-medium text-gray-400 uppercase">{o.campo}</span>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="px-4 py-3 text-xs text-gray-400 text-center font-bold">
                        No se encontraron resultados
                      </div>
                    )}
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex p-1 bg-gray-100 rounded-2xl w-fit">
          <div className="px-6 py-2.5 bg-white text-blue-600 rounded-xl text-xs font-black uppercase tracking-widest shadow-sm">
            Movimiento de Skid
          </div>
        </div>
      </div>

      {/* Notifications */}
      {success && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center space-x-3 text-emerald-700"
        >
          <CheckCircle2 className="w-5 h-5" />
          <p className="text-sm font-bold">{success}</p>
        </motion.div>
      )}
      {error && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center space-x-3 text-rose-700"
        >
          <AlertCircle className="w-5 h-5" />
          <p className="text-sm font-bold">{error}</p>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Movement Form */}
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-black/5 space-y-8">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-2 rounded-xl">
                <Truck className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-black text-gray-900 uppercase tracking-tighter">Traslado de Equipos de Superficie</h3>
            </div>

            <div className="space-y-6">
              <SearchableDropdown 
                label="Origen (Well o Base)"
                value={sourcePozo}
                onChange={setSourcePozo}
                search={sourceSearch}
                onSearchChange={setSourceSearch}
                options={filteredSourceOptions}
                placeholder="Seleccionar Origen..."
              />

              <div className="flex justify-center">
                <div className="bg-gray-100 p-2 rounded-full">
                  <ArrowRight className="w-5 h-5 text-gray-400 rotate-90 lg:rotate-0" />
                </div>
              </div>

              <SearchableDropdown 
                label="Destino (Well o Base)"
                value={targetPozo}
                onChange={setTargetPozo}
                search={targetSearch}
                onSearchChange={setTargetSearch}
                options={filteredTargetOptions}
                placeholder="Seleccionar Destino..."
              />

              <button
                onClick={handleSkidMove}
                disabled={loading}
                className="w-full py-4 bg-blue-600 text-white font-black rounded-2xl shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all disabled:opacity-50 uppercase tracking-widest text-xs"
              >
                {loading ? 'Procesando...' : 'Confirmar Movimiento'}
              </button>
            </div>
          </div>

          {/* Info Card */}
          <div className="bg-blue-50/50 p-8 rounded-[2.5rem] border border-blue-100 flex flex-col justify-center">
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-blue-100">
                <h4 className="text-xs font-black text-blue-600 uppercase tracking-widest mb-4">¿Qué se moverá?</h4>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 text-sm font-bold text-gray-700">
                    <Box className="w-4 h-4 text-blue-400" />
                    <span>Variador de Frecuencia (VSD)</span>
                  </div>
                  <div className="flex items-center space-x-3 text-sm font-bold text-gray-700">
                    <Database className="w-4 h-4 text-blue-400" />
                    <span>Filtro de Salida (Sine Filter)</span>
                  </div>
                  <div className="flex items-center space-x-3 text-sm font-bold text-gray-700">
                    <Zap className="w-4 h-4 text-blue-400" />
                    <span>Transformador Elevador (SUT)</span>
                  </div>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed font-medium">
                Al realizar un movimiento, el sistema actualizará automáticamente el origen del VSD y limpiará la información del pozo anterior si corresponde.
              </p>
            </div>
          </div>
        </div>
    </div>
  );
};
