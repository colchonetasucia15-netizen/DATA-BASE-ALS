import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { motion } from 'motion/react';
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle2, Loader2, Table, X } from 'lucide-react';
import { ESPRecord, EquipmentComponent } from '../types';
import { calculateRunLife } from '../utils';

interface Props {
  onImport: (records: ESPRecord[]) => Promise<void>;
}

export const ExcelImport: React.FC<Props> = ({ onImport }) => {
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [previewData, setPreviewData] = useState<any[][] | null>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setError(null);
    setSuccess(null);
    setPreviewData(null);

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary', cellDates: true });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        
        const rows = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
        if (rows.length < 3) {
          setError('El archivo no tiene suficientes filas.');
          return;
        }

        setPreviewData(rows); // Show all rows for preview

        // Find the header row by looking for "NICK" or "POZO"
        let headerRowIdx = -1;
        for (let i = 0; i < Math.min(rows.length, 15); i++) {
          const rowStr = (rows[i] || []).join('|').toUpperCase();
          if (rowStr.includes('NICK') || rowStr.includes('POZO')) {
            headerRowIdx = i;
            break;
          }
        }

        if (headerRowIdx === -1) {
          setError('No se pudo encontrar la fila de encabezados (NICK/POZO). Verifique el formato.');
          return;
        }

        const rawTitles = rows[headerRowIdx] || [];
        const rawSubtitles = rows[headerRowIdx + 1] || [];
        const maxCols = Math.max(rawTitles.length, rawSubtitles.length);
        
        // Fill titles to handle merged category headers (Fila 1)
        const titles: string[] = [];
        let currentTitle = '';
        for (let i = 0; i < maxCols; i++) {
          const t = String(rawTitles[i] || '').trim();
          if (t) currentTitle = t;
          titles.push(currentTitle);
        }

        // Subtitles (Fila 2)
        const subtitles: string[] = [];
        for (let i = 0; i < maxCols; i++) {
          subtitles.push(String(rawSubtitles[i] || '').trim());
        }

        const dataRows = rows.slice(headerRowIdx + 2);

        // Pre-calculate identifier column indices to speed up filtering
        const pozoIndices: number[] = [];
        const nickIndices: number[] = [];
        const activoIndices: number[] = [];

        titles.forEach((t, i) => {
          const ut = t.toUpperCase();
          const us = (subtitles[i] || '').toUpperCase();
          if (ut.includes('POZO') || us === 'POZO') pozoIndices.push(i);
          if (ut.includes('NICK') || us === 'NICK') nickIndices.push(i);
          if (ut.includes('ACTIVO') || us === 'ACTIVO') activoIndices.push(i);
        });

        const mappedRecords: ESPRecord[] = dataRows
          .filter((row) => {
            // A row is valid if it has a POZO, NICK, or ACTIVO
            const hasPozo = pozoIndices.some(idx => row[idx] && String(row[idx]).trim() !== '');
            const hasNick = nickIndices.some(idx => row[idx] && String(row[idx]).trim() !== '');
            const hasActivo = activoIndices.some(idx => row[idx] && String(row[idx]).trim() !== '');
            
            return hasPozo || hasNick || hasActivo;
          })
          .map((row) => {
            const getVal = (title: string, subtitle?: string) => {
            const sTitle = title.toUpperCase().trim();
            const sSub = subtitle?.toUpperCase().trim();

            // 1. Try to find by Title + Subtitle pairing
            for (let i = 0; i < titles.length; i++) {
              const t = titles[i].toUpperCase();
              const s = subtitles[i].toUpperCase();

              const tMatch = t.includes(sTitle);
              
              if (tMatch) {
                if (sSub) {
                  const sMatch = s.includes(sSub) || t.includes(sSub);
                  if (sMatch) return row[i];
                } else {
                  return row[i];
                }
              }
            }
            
            // 2. Fallback: Search in subtitles row (Row 2) if no subtitle requested
            if (!subtitle) {
              for (let i = 0; i < subtitles.length; i++) {
                const s = subtitles[i].toUpperCase();
                if (s === sTitle || s.includes(sTitle)) return row[i];
              }
            }

            // 3. Last Resort: Search in titles row (Row 1) for exact or partial match
            if (!subtitle) {
              for (let i = 0; i < titles.length; i++) {
                const t = titles[i].toUpperCase();
                if (t === sTitle || t.includes(sTitle)) return row[i];
              }
            }

            return undefined;
          };

          const parseDate = (val: any) => {
            if (!val) return null;
            if (val instanceof Date) return val.toISOString().split('T')[0];
            const s = String(val).trim();
            if (s.toUpperCase() === 'RUNNING' || s === '') return null;
            return s;
          };

          const parseEstado = (val: any): 'NEW' | 'USED' | 'REP' | null => {
            const s = String(val || '').toUpperCase();
            if (s.includes('NEW')) return 'NEW';
            if (s.includes('USED')) return 'USED';
            if (s.includes('REP')) return 'REP';
            return null;
          };

          const mapComp = (title: string): EquipmentComponent => {
            const getCompVal = (sub: string) => {
              const val = getVal(title, sub);
              return val !== undefined ? String(val).trim() : '';
            };

            return {
              estado: parseEstado(getVal(title, 'ESTADO')) || parseEstado(getVal(title, 'NEW/USED/REP')),
              serie: getCompVal('SERIE') || getCompVal('S/N'),
              etapas: getCompVal('ETAPAS'),
              modelo: getCompVal('MODELO'),
              descripcion: getCompVal('DESCRIPCION'),
              pn: getCompVal('P/N'),
              sn: getCompVal('S/N'),
              hp: getCompVal('HP'),
              vol: getCompVal('VOL.'),
              amp: getCompVal('AMP.'),
              longitud: getCompVal('LONGITUD'),
              awg: getCompVal('AWG'),
              tipo: getCompVal('PLANO/REDONDO'),
              kva: getCompVal('KVA'),
              controlador: getCompVal('CONTROLADOR'),
              ampOut: getCompVal('AMP OUT'),
              pulsos: getCompVal('PULSOS'),
              marca: getCompVal('MARCA'),
              profundidad: getCompVal('PROFUNDIDAD'),
            };
          };

          const rawFechaRun = getVal('FECHA RUN');
          const rawFechaFalla = getVal('FECHA FALLA');
          const rawFechaPull = getVal('FECHA PULL');

          const fechaRun = parseDate(rawFechaRun);
          const fechaFalla = parseDate(rawFechaFalla);
          const fechaPull = parseDate(rawFechaPull);

          const pullVal = String(rawFechaPull || '').toUpperCase().trim();
          const isPulling = rawFechaPull && pullVal !== 'RUNNING' && pullVal !== '';
          const isFailed = fechaFalla && (!rawFechaPull || pullVal === 'RUNNING');
          const isOperativo = !fechaFalla && (!rawFechaPull || pullVal === 'RUNNING');

          let estadoInv: 'OPERATIVO' | 'FALLADO' | 'PULLING' = 'OPERATIVO';
          if (isPulling) estadoInv = 'PULLING';
          else if (isFailed) estadoInv = 'FALLADO';
          else if (isOperativo) estadoInv = 'OPERATIVO';

          const runLifeExcel = Number(getVal('RUN LIFE @ FALLA') || getVal('RUN LIFE @ PULLING') || 0);
          const runLife = runLifeExcel || calculateRunLife(fechaRun || '', fechaFalla || undefined, fechaPull || undefined);

          return {
            nick: String(getVal('NICK') || ''),
            activo: String(getVal('ACTIVO') || ''),
            bloque: String(getVal('BLOQUE') || ''),
            campo: String(getVal('CAMPO') || ''),
            cluster: String(getVal('CLUSTER') || ''),
            pozo: String(getVal('POZO') || ''),
            runNumber: Number(getVal('# RUN') || 1),
            als: String(getVal('ALS') || 'ESP'),
            proveedor: String(getVal('PROVEEDOR') || ''),
            fechaRun: fechaRun || '',
            fechaFalla: fechaFalla || undefined,
            fechaPull: fechaPull || undefined,
            estadoInventario: estadoInv,
            runLife,
            timestamp: new Date().toISOString(),
            fondo: {
              pumpGasHandled: mapComp('PUMP (GAS HANDLED)'),
              pumpLower: mapComp('PUMP LOWER'),
              pumpCentralA: mapComp('PUMP CENTRAL A'),
              pumpCentralB: mapComp('PUMP CENTRAL B'),
              pumpCentralC: mapComp('PUMP CENTRAL C'),
              pumpCentralD: mapComp('PUMP CENTRAL D'),
              pumpUpper: mapComp('PUMP UPPER'),
              intakeSeparador: mapComp('INTAKE/SEPARADOR DE GAS'),
              protectorSuperior: mapComp('PROTECTOR (SELLO)  SUPERIOR'),
              protectorCentral: mapComp('PROTECTOR (SELLO) CENTRAL'),
              protectorInferior: mapComp('PROTECTOR (SELLO) INFERIOR'),
              motorUT: mapComp('MOTOR UT'),
              motorCT: mapComp('MOTOR CT'),
              motorLT: mapComp('MOTOR LT'),
              tecMotor: String(getVal('TEC.MOTOR') || getVal('AM/PMM') || ''),
              sensor: mapComp('SENSOR'),
              espSummary: String(getVal('ESP', 'RESUMEN') || getVal('ESP') || ''),
            },
            cable: {
              mle: mapComp('MLE'),
              cableFondo: {
                ...mapComp('CABLE (FONDO)'),
                estado2: String(getVal('CABLE (FONDO)', 'ESTADO 2') || getVal('ESTADO 2') || ''),
              },
            },
            superficie: {
              vsd: {
                ...mapComp('VSD'),
                origen: String(getVal('VSD', 'ORIGEN') || getVal('ORIGEN') || ''),
              },
              filter: mapComp('SHIFT/FILTRO ENTRADA'),
              sut: mapComp('SUT'),
            },
            yTool: mapComp('Y-TOOL'),
            detalles: String(getVal('DETALLES/COMENTARIOS') || ''),
          };
        });

        await onImport(mappedRecords);
        setSuccess(`Se han importado ${mappedRecords.length} registros exitosamente.`);
      } catch (err) {
        console.error('Import error:', err);
        setError('Error al procesar el archivo. Asegúrese de que el formato sea correcto.');
      } finally {
        setImporting(false);
        // Reset input
        e.target.value = '';
      }
    };
    reader.readAsBinaryString(file);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between bg-white p-6 rounded-3xl border border-black/5 shadow-sm">
        <div className="flex items-center space-x-4">
          <div className="bg-emerald-100 p-3 rounded-2xl">
            <FileSpreadsheet className="w-6 h-6 text-emerald-600" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">Importar Base de Datos</h3>
            <p className="text-sm text-gray-500">Cargue su archivo Excel (.xlsx, .xls) para poblar el inventario.</p>
          </div>
        </div>

        <label className={`
          relative flex items-center px-6 py-3 bg-emerald-600 text-white font-bold rounded-xl 
          cursor-pointer hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100
          ${importing ? 'opacity-50 cursor-not-allowed' : ''}
        `}>
          {importing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Procesando...
            </>
          ) : (
            <>
              <Upload className="w-4 h-4 mr-2" />
              Seleccionar Archivo
            </>
          )}
          <input
            type="file"
            className="hidden"
            accept=".xlsx, .xls"
            onChange={handleFileUpload}
            disabled={importing}
          />
        </label>
      </div>

      {error && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center p-4 bg-rose-50 border border-rose-100 rounded-2xl text-rose-600 text-sm font-medium"
        >
          <AlertCircle className="w-4 h-4 mr-2" />
          {error}
        </motion.div>
      )}

      {success && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center p-4 bg-emerald-50 border border-emerald-100 rounded-2xl text-emerald-600 text-sm font-medium"
        >
          <CheckCircle2 className="w-4 h-4 mr-2" />
          {success}
        </motion.div>
      )}

      {previewData && (
        <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden mt-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-50 p-2 rounded-xl">
                <Table className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h4 className="font-bold text-gray-900">Vista Previa Completa del Archivo</h4>
                <p className="text-xs text-gray-500">Mostrando todas las filas detectadas en el Excel</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-xs text-gray-400 hidden md:block">Desliza para ver más columnas →</span>
              <button 
                onClick={() => setPreviewData(null)}
                className="p-2 hover:bg-gray-100 rounded-xl transition-colors text-gray-400 hover:text-gray-600"
                title="Cerrar Vista Previa"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
          <div className="overflow-x-auto overflow-y-auto max-h-[600px] border border-gray-100 rounded-2xl shadow-inner bg-gray-50/30">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="sticky top-0 z-10">
                <tr className="bg-gray-100 shadow-sm">
                  <th className="p-3 border-b border-r border-gray-200 text-gray-400 w-12 text-center">#</th>
                  {previewData[0]?.map((_, i) => (
                    <th key={i} className="p-3 border-b border-r border-gray-200 text-gray-600 font-bold whitespace-nowrap min-w-[120px]">
                      Columna {i + 1}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {previewData.map((row, rowIndex) => (
                  <tr key={rowIndex} className={`${rowIndex < 2 ? "bg-blue-50/50" : "bg-white hover:bg-gray-50"} transition-colors`}>
                    <td className="p-3 border-b border-r border-gray-100 bg-gray-50/50 text-gray-400 font-mono text-center">{rowIndex + 1}</td>
                    {row.map((cell, cellIndex) => (
                      <td key={cellIndex} className="p-3 border-b border-r border-gray-100 whitespace-nowrap max-w-[200px] truncate text-gray-600">
                        {cell === undefined || cell === null ? "" : String(cell)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-6 flex items-center space-x-4 p-4 bg-blue-50/30 rounded-2xl border border-blue-100/50">
            <div className="w-2 h-2 bg-blue-400 rounded-full" />
            <p className="text-xs text-gray-600 italic">
              Las filas resaltadas en azul son los <strong>Encabezados</strong> (Títulos y Subtítulos) que el sistema utiliza para mapear los datos.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
