import React from 'react';
import { motion } from 'motion/react';
import { ChevronRight, Box, Anchor, Zap } from 'lucide-react';

interface CategoryProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  onClick?: () => void;
}

const CategoryCard: React.FC<CategoryProps> = ({ title, description, icon, color, onClick }) => (
  <motion.div
    whileHover={{ y: -8, shadow: "0 25px 50px -12px rgba(0, 0, 0, 0.15)" }}
    onClick={onClick}
    className="bg-white rounded-[2.5rem] shadow-xl border border-black/5 overflow-hidden group cursor-pointer flex flex-col h-full"
  >
    <div className={`h-56 overflow-hidden ${color.replace('bg-', 'bg-').replace('600', '50')} relative flex items-center justify-center`}>
      <div className="absolute inset-0 bg-gradient-to-br from-white/40 to-transparent z-10" />
      <div className={`${color} p-8 rounded-[2rem] text-white shadow-2xl z-20 transform -rotate-3 group-hover:rotate-0 group-hover:scale-110 transition-all duration-500`}>
        {React.cloneElement(icon as React.ReactElement, { className: "w-16 h-16" })}
      </div>
    </div>
    <div className="p-8 flex flex-col flex-1">
      <h3 className="text-xl font-black text-gray-900 mb-3 tracking-tight tracking-tight uppercase">{title}</h3>
      <p className="text-sm text-gray-500 mb-8 line-clamp-2 leading-relaxed">{description}</p>
      <div className="mt-auto flex items-center justify-between">
        <div className="flex items-center text-blue-600 font-black text-xs uppercase tracking-widest group-hover:translate-x-2 transition-transform">
          Ver Inventario <ChevronRight className="w-4 h-4 ml-1" />
        </div>
        <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center group-hover:bg-blue-50 transition-colors">
          <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-blue-600" />
        </div>
      </div>
    </div>
  </motion.div>
);

export const EquipmentGallery: React.FC<{ onCategorySelect?: (cat: string) => void }> = ({ onCategorySelect }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
      <CategoryCard
        title="Equipo de Superficie"
        description="Variadores de Frecuencia (VSD), transformadores y sistemas de control en superficie."
        icon={<Box className="w-5 h-5" />}
        color="bg-blue-600"
        onClick={() => onCategorySelect?.('superficie')}
      />
      <CategoryCard
        title="Equipo de Fondo"
        description="Bombas centrífugas, motores sumergibles, protectores y sensores de fondo."
        icon={<Anchor className="w-5 h-5" />}
        color="bg-emerald-600"
        onClick={() => onCategorySelect?.('fondo')}
      />
      <CategoryCard
        title="Cable de Fondo"
        description="Cables de potencia, MLE y accesorios de sujeción para el pozo."
        icon={<Zap className="w-5 h-5" />}
        color="bg-amber-600"
        onClick={() => onCategorySelect?.('cable')}
      />
    </div>
  );
};
