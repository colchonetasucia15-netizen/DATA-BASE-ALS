import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  AlertCircle, 
  Clock, 
  Users, 
  Box, 
  Anchor, 
  Zap,
  ShieldCheck,
  BarChart3,
  TrendingDown,
  Layers,
  MapPin
} from 'lucide-react';
import { DashboardStats } from '../types';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid,
  Legend,
  Label
} from 'recharts';

interface Props {
  stats: DashboardStats;
}

export const DashboardCards: React.FC<Props> = ({ stats }) => {
  const [confirmModal, setConfirmModal] = useState<{
    show: boolean;
    type: 'FALLADO' | 'PULLING';
    recordId: string;
    pozo: string;
  } | null>(null);

  const initialPullingForm = {
    razonPulling: '',
    razonEspecificaPulling: '',
    fecha: new Date().toISOString().split('T')[0],
    componentStatuses: {
      PUMP: 'PENDIENTE',
      INTAKE: 'PENDIENTE',
      PROTECTOR: 'PENDIENTE',
      MOTOR: 'PENDIENTE',
      SENSOR: 'PENDIENTE',
      CABLE: 'PENDIENTE',
      VSD: 'PENDIENTE'
    }
  };

  const [pullingForm, setPullingForm] = useState(initialPullingForm);

  const [fallaForm, setFallaForm] = useState({
    fecha: new Date().toISOString().split('T')[0]
  });

  const mainCards = [
    { 
      title: 'Salud de Flota', 
      value: `${stats.healthScore}%`, 
      icon: ShieldCheck, 
      color: 'text-emerald-600', 
      bg: 'bg-emerald-50',
      detail: 'Operativos vs Fallados'
    },
    { 
      title: 'MTBF Promedio', 
      value: `${stats.mtbf}d`, 
      icon: TrendingDown, 
      color: 'text-rose-600', 
      bg: 'bg-rose-50',
      detail: 'Run Life en Fallas'
    },
    { 
      title: 'Run Life Promedio', 
      value: `${stats.avgRunLife}d`, 
      icon: Clock, 
      color: 'text-amber-600', 
      bg: 'bg-amber-50',
      detail: 'Días totales'
    },
    { 
      title: 'Total Sistemas', 
      value: stats.totalRecords, 
      icon: Activity, 
      color: 'text-blue-600', 
      bg: 'bg-blue-50',
      detail: 'Inventario Activo'
    },
    { 
      title: 'Pendientes Post-Pulling', 
      value: stats.totalPendingPostPull || 0, 
      icon: AlertCircle, 
      color: 'text-orange-600', 
      bg: 'bg-orange-50',
      detail: 'Clasificación pendiente'
    },
  ];

  return (
    <div className="space-y-4">
      {/* Top Stats Row - More Compact */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        {mainCards.map((card, index) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-white p-3.5 rounded-2xl shadow-sm border border-slate-200/60 flex flex-col hover:shadow-md hover:border-blue-200 transition-all group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-16 h-16 bg-slate-50 rounded-bl-full -mr-8 -mt-8 group-hover:bg-blue-50 transition-colors" />
            <div className="flex items-center space-x-2.5 mb-2 relative z-10">
              <div className={`${card.bg} p-1.5 rounded-lg group-hover:scale-110 transition-transform`}>
                <card.icon className={`w-3.5 h-3.5 ${card.color}`} />
              </div>
              <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{card.title}</span>
            </div>
            <div className="flex items-baseline space-x-1.5 relative z-10">
              <p className="text-xl font-black text-slate-900 tracking-tight">{card.value}</p>
              <span className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter truncate max-w-[60px]">{card.detail}</span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Main Bento Grid - More Compact & Denser */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-3">
        
        {/* Status Distribution - Compact Pie */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="lg:col-span-3 bg-white p-4 rounded-3xl shadow-sm border border-slate-200/60 flex flex-col"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <BarChart3 className="w-3 h-3 text-blue-600" />
              <h3 className="text-[9px] font-black text-slate-900 uppercase tracking-widest">Estado</h3>
            </div>
          </div>
          <div className="h-32 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.statusDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={25}
                  outerRadius={40}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {stats.statusDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', fontSize: '9px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-3 gap-1 mt-1">
            {stats.statusDistribution.map((s) => (
              <div key={s.name} className="flex flex-col items-center p-1 bg-slate-50 rounded-lg">
                <div className="w-1 h-1 rounded-full mb-0.5" style={{ backgroundColor: s.color }} />
                <span className="text-[7px] font-bold text-slate-400 uppercase">{s.name}</span>
                <span className="text-[10px] font-black text-slate-900">{s.value}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Provider Distribution - Compact Bar */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-5 bg-white p-4 rounded-3xl shadow-sm border border-slate-200/60"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <Users className="w-3 h-3 text-emerald-600" />
              <h3 className="text-[9px] font-black text-slate-900 uppercase tracking-widest">Sistemas / Proveedor</h3>
            </div>
          </div>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.providerDistribution} layout="vertical" margin={{ left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f1f5f9" />
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 8, fontWeight: 700, fill: '#64748b' }}
                  width={80}
                />
                <Tooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '12px', border: 'none', fontSize: '9px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }} />
                <Bar dataKey="value" fill="#3b82f6" radius={[0, 4, 4, 0]} barSize={12} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* KVA Distribution - Compact List */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.15 }}
          className="lg:col-span-4 bg-white p-4 rounded-3xl shadow-sm border border-slate-200/60"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <Layers className="w-3 h-3 text-amber-600" />
              <h3 className="text-[9px] font-black text-slate-900 uppercase tracking-widest">Distribución KVA</h3>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-1.5 max-h-44 overflow-y-auto custom-scrollbar pr-1">
            {stats.kvaDistribution.sort((a,b) => b.value - a.value).map((item) => (
              <div key={item.name} className="flex items-center justify-between p-1.5 bg-slate-50 rounded-lg border border-slate-100">
                <span className="text-[9px] font-bold text-slate-500">{item.name} KVA</span>
                <span className="text-[10px] font-black text-slate-900">{item.value}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Failures by Provider - Compact Bar */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-4 bg-white p-4 rounded-3xl shadow-sm border border-slate-200/60"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-3 h-3 text-rose-600" />
              <h3 className="text-[9px] font-black text-slate-900 uppercase tracking-widest">Fallas / Proveedor</h3>
            </div>
          </div>
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.failureByProvider}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 7, fontWeight: 700, fill: '#94a3b8' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 7, fontWeight: 700, fill: '#94a3b8' }} />
                <Bar dataKey="value" fill="#ef4444" radius={[4, 4, 0, 0]} barSize={16} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Top 5 Wells & Recent Failures - Combined Compact */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.25 }}
          className="lg:col-span-4 bg-white p-4 rounded-3xl shadow-sm border border-slate-200/60"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <MapPin className="w-3 h-3 text-indigo-600" />
              <h3 className="text-[9px] font-black text-slate-900 uppercase tracking-widest">Pozos Críticos</h3>
            </div>
          </div>
          <div className="space-y-1.5">
            <p className="text-[7px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Top 3 Run Life</p>
            {stats.topWells.slice(0, 3).map((well) => (
              <div key={well.pozo} className="flex items-center justify-between p-1.5 bg-emerald-50/40 rounded-lg border border-emerald-100">
                <span className="text-[9px] font-black text-slate-900">{well.pozo}</span>
                <span className="text-[9px] font-bold text-emerald-600">{well.runLife}d</span>
              </div>
            ))}
            <div className="h-px bg-slate-100 my-1.5" />
            <p className="text-[7px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Fallas Prematuras</p>
            {stats.recentFailures.slice(0, 3).map((well) => (
              <div key={well.pozo} className="flex items-center justify-between p-1.5 bg-rose-50/40 rounded-lg border border-rose-100">
                <span className="text-[9px] font-black text-slate-900">{well.pozo}</span>
                <span className="text-[9px] font-bold text-rose-600">{well.runLife}d</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Equipment Condition - Compact (No Surface) */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="lg:col-span-4 bg-white p-4 rounded-3xl shadow-sm border border-slate-200/60"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <Zap className="w-3 h-3 text-indigo-600" />
              <h3 className="text-[9px] font-black text-slate-900 uppercase tracking-widest">Estado Componentes</h3>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {(['fondo', 'cable'] as const).map((cat) => (
              <div key={cat} className="p-2 bg-slate-50 rounded-xl border border-slate-100">
                <div className="flex items-center space-x-1 mb-1.5">
                  {cat === 'fondo' ? <Anchor className="w-2.5 h-2.5 text-emerald-600" /> : <Zap className="w-2.5 h-2.5 text-amber-600" />}
                  <span className="text-[8px] font-black text-slate-900 uppercase tracking-widest">{cat}</span>
                </div>
                <div className="space-y-1.5">
                  {[
                    { label: 'N', val: stats.equipmentCondition[cat].new, color: 'bg-emerald-500' },
                    { label: 'U', val: stats.equipmentCondition[cat].used, color: 'bg-blue-500' },
                    { label: 'R', val: stats.equipmentCondition[cat].rep, color: 'bg-amber-500' }
                  ].map(item => (
                    <div key={item.label} className="flex items-center space-x-1.5">
                      <span className="text-[7px] font-bold text-slate-400 w-1.5">{item.label}</span>
                      <div className="flex-1 bg-slate-200 h-0.5 rounded-full overflow-hidden">
                        <div className={`${item.color} h-full`} style={{ width: `${(item.val / Math.max(stats.totalRecords, 1)) * 100}%` }} />
                      </div>
                      <span className="text-[8px] font-black text-slate-900">{item.val}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Campo Performance - New Chart */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.35 }}
          className="lg:col-span-8 bg-white p-4 rounded-3xl shadow-sm border border-slate-200/60"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <BarChart3 className="w-3 h-3 text-indigo-600" />
              <h3 className="text-[9px] font-black text-slate-900 uppercase tracking-widest">Estado por Campo</h3>
            </div>
          </div>
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.statusByCampo}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="campo" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 7, fontWeight: 700, fill: '#94a3b8' }}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 7, fontWeight: 700, fill: '#94a3b8' }}
                />
                <Tooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '12px', border: 'none', fontSize: '9px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '7px', fontWeight: 700, textTransform: 'uppercase', paddingTop: '10px' }} />
                <Bar dataKey="operativo" stackId="a" fill="#10b981" barSize={24} />
                <Bar dataKey="fallado" stackId="a" fill="#ef4444" barSize={24} />
                <Bar dataKey="pulling" stackId="a" fill="#f59e0b" radius={[4, 4, 0, 0]} barSize={24} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Avg Run Life by Provider - New Chart */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-4 bg-white p-4 rounded-3xl shadow-sm border border-slate-200/60"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <TrendingDown className="w-3 h-3 text-emerald-600" />
              <h3 className="text-[9px] font-black text-slate-900 uppercase tracking-widest">RL Promedio / Prov</h3>
            </div>
          </div>
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.avgRunLifeByProvider} layout="vertical" margin={{ left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f1f5f9" />
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 7, fontWeight: 700, fill: '#64748b' }}
                  width={80}
                />
                <Tooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '12px', border: 'none', fontSize: '9px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }} />
                <Bar dataKey="value" fill="#10b981" radius={[0, 4, 4, 0]} barSize={12} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Run Life Distribution - New Chart */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className="lg:col-span-12 bg-white p-4 rounded-3xl shadow-sm border border-slate-200/60"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <Activity className="w-3 h-3 text-blue-600" />
              <h3 className="text-[9px] font-black text-slate-900 uppercase tracking-widest">Distribución de Run Life (Días)</h3>
            </div>
          </div>
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.runLifeDistribution}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="range" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 7, fontWeight: 700, fill: '#94a3b8' }}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 7, fontWeight: 700, fill: '#94a3b8' }}
                />
                <Tooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '12px', border: 'none', fontSize: '9px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }} />
                <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Quick Status Update Widget - New */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.55 }}
          className="lg:col-span-12 bg-white p-5 rounded-[2rem] shadow-xl shadow-blue-50/50 border border-blue-100"
        >
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-1.5 rounded-lg shadow-lg shadow-blue-200">
                <Zap className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Actualización Rápida</h3>
                <p className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter">Pozos Críticos (Mayor Run Life)</p>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {stats.topWells.slice(0, 4).map((well) => (
              <div key={well.pozo} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100 hover:border-blue-200 transition-all group">
                <div className="flex flex-col">
                  <span className="text-xs font-black text-slate-900">{well.pozo}</span>
                  <span className="text-[8px] font-bold text-slate-400 uppercase">{well.runLife}d</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <button 
                    onClick={() => setConfirmModal({ show: true, type: 'FALLADO', recordId: well.pozo, pozo: well.pozo })}
                    className="p-1.5 bg-white text-rose-600 rounded-lg hover:bg-rose-600 hover:text-white shadow-sm border border-rose-100 transition-all active:scale-90"
                    title="Marcar como Falla"
                  >
                    <AlertCircle className="w-3.5 h-3.5" />
                  </button>
                  <button 
                    onClick={() => setConfirmModal({ show: true, type: 'PULLING', recordId: well.pozo, pozo: well.pozo })}
                    className="p-1.5 bg-white text-amber-600 rounded-lg hover:bg-amber-600 hover:text-white shadow-sm border border-amber-100 transition-all active:scale-90"
                    title="Marcar como Pulling"
                  >
                    <Anchor className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {confirmModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[2.5rem] shadow-2xl border border-gray-100 w-full max-w-md overflow-hidden"
            >
              <div className="p-8">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 ${
                  confirmModal.type === 'FALLADO' ? 'bg-rose-50 text-rose-600' : 'bg-amber-50 text-amber-600'
                }`}>
                  {confirmModal.type === 'FALLADO' ? <AlertCircle className="w-8 h-8" /> : <Anchor className="w-8 h-8" />}
                </div>
                
                <h3 className="text-2xl font-black text-gray-900 mb-2 uppercase tracking-tighter">
                  Confirmar Cambio de Estado
                </h3>
                <p className="text-gray-500 text-sm mb-8">
                  ¿Estás seguro de que deseas marcar el pozo <span className="font-black text-gray-900">{confirmModal.pozo}</span> como <span className={`font-black ${
                    confirmModal.type === 'FALLADO' ? 'text-rose-600' : 'text-amber-600'
                  }`}>{confirmModal.type}</span>? Esta acción actualizará los registros técnicos.
                </p>

                {confirmModal.type === 'PULLING' && (
                  <div className="space-y-4 mb-8">
                    <div>
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">Fecha de Pulling</label>
                      <input 
                        type="date"
                        value={pullingForm.fecha}
                        onChange={(e) => setPullingForm(prev => ({ ...prev, fecha: e.target.value }))}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-amber-500 outline-none transition-all text-sm"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">Razón de Pulling</label>
                      <input 
                        type="text"
                        value={pullingForm.razonPulling}
                        onChange={(e) => setPullingForm(prev => ({ ...prev, razonPulling: e.target.value }))}
                        placeholder="Ej: Falla Eléctrica, Cambio de Diseño..."
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-amber-500 outline-none transition-all text-sm"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">Razón Específica</label>
                      <textarea 
                        value={pullingForm.razonEspecificaPulling}
                        onChange={(e) => setPullingForm(prev => ({ ...prev, razonEspecificaPulling: e.target.value }))}
                        placeholder="Detalles adicionales sobre la extracción..."
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-amber-500 outline-none transition-all text-sm h-24 resize-none"
                      />
                    </div>

                    <div className="pt-4 border-t border-gray-100">
                      <h4 className="text-[10px] font-black text-gray-900 uppercase tracking-widest mb-4">Estado Post-Pulling de Componentes</h4>
                      <div className="grid grid-cols-2 gap-3">
                        {Object.keys(pullingForm.componentStatuses).map((comp) => (
                          <div key={comp}>
                            <label className="text-[9px] font-bold text-gray-400 uppercase mb-1 block">{comp}</label>
                            <select
                              value={pullingForm.componentStatuses[comp as keyof typeof pullingForm.componentStatuses]}
                              onChange={(e) => setPullingForm(prev => ({
                                ...prev,
                                componentStatuses: {
                                  ...prev.componentStatuses,
                                  [comp]: e.target.value
                                }
                              }))}
                              className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-[11px] focus:ring-2 focus:ring-amber-500 outline-none"
                            >
                              <option value="PENDIENTE">PENDIENTE</option>
                              <option value="BUENO PARA USAR">BUENO PARA USAR</option>
                              <option value="REPARACIÓN">REPARACIÓN</option>
                              <option value="REMANUFACTURA">REMANUFACTURA</option>
                              <option value="INSPECCIÓN">INSPECCIÓN</option>
                              <option value="PERDIDO">PERDIDO</option>
                              <option value="SCRAP">SCRAP</option>
                            </select>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {confirmModal.type === 'FALLADO' && (
                  <div className="space-y-4 mb-8">
                    <div>
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">Fecha de Falla</label>
                      <input 
                        type="date"
                        value={fallaForm.fecha}
                        onChange={(e) => setFallaForm(prev => ({ ...prev, fecha: e.target.value }))}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none transition-all text-sm"
                      />
                    </div>
                  </div>
                )}

                <div className="flex items-center space-x-3">
                  <button 
                    onClick={() => {
                      setConfirmModal(null);
                      setPullingForm(initialPullingForm);
                    }}
                    className="flex-1 px-6 py-4 bg-gray-100 text-gray-600 rounded-2xl font-bold hover:bg-gray-200 transition-all"
                  >
                    Cancelar
                  </button>
                  <button 
                    onClick={() => {
                      if (confirmModal.type === 'PULLING') {
                        (window as any).handleStatusUpdate?.(confirmModal.recordId, 'PULLING', pullingForm);
                      } else {
                        (window as any).handleStatusUpdate?.(confirmModal.recordId, 'FALLADO', undefined, fallaForm);
                      }
                      setConfirmModal(null);
                      setPullingForm(initialPullingForm);
                      setFallaForm({
                        fecha: new Date().toISOString().split('T')[0]
                      });
                    }}
                    className={`flex-1 px-6 py-4 text-white rounded-2xl font-bold shadow-lg transition-all active:scale-95 ${
                      confirmModal.type === 'FALLADO' ? 'bg-rose-600 shadow-rose-200 hover:bg-rose-700' : 'bg-amber-600 shadow-amber-200 hover:bg-amber-700'
                    }`}
                  >
                    Confirmar
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
