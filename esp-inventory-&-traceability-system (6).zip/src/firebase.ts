import { initializeApp } from 'firebase/app';
import { getAnalytics, isSupported } from 'firebase/analytics';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, signOut, User } from 'firebase/auth';
import { getFirestore, collection, doc, setDoc, getDoc, getDocs, deleteDoc, onSnapshot, query, where, orderBy, getDocFromServer, writeBatch, updateDoc, serverTimestamp } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Analytics safely
export let analytics: any = null;
if (typeof window !== 'undefined') {
  isSupported().then((supported) => {
    if (supported) {
      analytics = getAnalytics(app);
    }
  }).catch(err => console.warn('Firebase Analytics not supported in this environment:', err));
}

export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

export const googleProvider = new GoogleAuthProvider();

export const loginWithGoogle = () => signInWithPopup(auth, googleProvider);
export const logout = () => signOut(auth);
export const onAuthChange = (callback: (user: User | null) => void) => onAuthStateChanged(auth, callback);

// Error Handling Types
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

// Quota Error Listener
type QuotaErrorListener = () => void;
const quotaListeners: QuotaErrorListener[] = [];

export function onQuotaExceeded(listener: QuotaErrorListener) {
  quotaListeners.push(listener);
  return () => {
    const index = quotaListeners.indexOf(listener);
    if (index > -1) quotaListeners.splice(index, 1);
  };
}

function notifyQuotaExceeded() {
  quotaListeners.forEach(listener => listener());
}

let lastQuotaErrorTime = 0;
const QUOTA_ERROR_LOG_COOLDOWN = 60000; // 1 minute

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null, shouldThrow: boolean = true) {
  const errorMsg = error instanceof Error ? error.message : String(error);
  const isQuotaError = errorMsg.includes("resource-exhausted") || 
                       errorMsg.includes("Quota limit exceeded") ||
                       errorMsg.includes("quota-exceeded");
  
  // Check for quota exhaustion
  if (isQuotaError) {
    notifyQuotaExceeded();
  }

  const errInfo: FirestoreErrorInfo = {
    error: errorMsg,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  
  const now = Date.now();
  const shouldLog = !isQuotaError || (now - lastQuotaErrorTime > QUOTA_ERROR_LOG_COOLDOWN);
  
  if (shouldLog) {
    if (isQuotaError) {
      console.warn('Firestore Quota Exceeded (suppressing further logs for 1 min): ', JSON.stringify(errInfo));
      lastQuotaErrorTime = now;
    } else {
      console.error('Firestore Error: ', JSON.stringify(errInfo));
    }
  }
  
  if (shouldThrow) {
    throw new Error(JSON.stringify(errInfo));
  }
  
  return errInfo;
}

// Connection Test
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if(error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration. ");
    }
  }
}
testConnection();

export { 
  collection, doc, setDoc, getDoc, getDocs, deleteDoc, onSnapshot, query, where, orderBy, writeBatch, updateDoc, serverTimestamp
};
export type { User };
