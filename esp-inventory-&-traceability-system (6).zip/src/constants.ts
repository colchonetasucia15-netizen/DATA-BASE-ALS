export const PROVEEDORES = ['Schlumberger', 'Baker Hughes', 'Halliburton', 'Weatherford', 'Borets', 'Novomet'];
export const ESTADOS = ['Operando', 'Apagado'];
export const RAZONES_PULL = [
  'Falla Eléctrica',
  'Falla Mecánica',
  'Cambio de Diseño',
  'Intervención de Pozo',
  'Baja Producción',
  'Otros'
];
export const CAMPOS = ['Campo A', 'Campo B', 'Campo C', 'Campo D'];
export const ACTIVOS = ['Activo Norte', 'Activo Sur', 'Activo Oriente'];
export const BLOQUES = ['Bloque 10', 'Bloque 15', 'Bloque 20'];
export const ENFRIAMIENTO_VSD = ['Aire Forzado', 'Líquido', 'Convección Natural'];
export const ESTADO_FILTROS = ['Bueno', 'Regular', 'Crítico', 'Requiere Cambio'];


