import { ESPRecord, EquipmentComponent } from '../types';
import { calculateRunLife } from '../utils';

export const mapExcelRowsToRecords = (rows: any[][]): ESPRecord[] => {
  if (rows.length < 3) {
    throw new Error('El archivo no tiene suficientes filas.');
  }

  // Find the header row by looking for "NICK" or "POZO"
  let headerRowIdx = -1;
  for (let i = 0; i < Math.min(rows.length, 15); i++) {
    const rowStr = (rows[i] || []).join('|').toUpperCase();
    if (rowStr.includes('NICK') || rowStr.includes('POZO')) {
      headerRowIdx = i;
      break;
    }
  }

  if (headerRowIdx === -1) {
    throw new Error('No se pudo encontrar la fila de encabezados (NICK/POZO). Verifique el formato.');
  }

  const rawTitles = rows[headerRowIdx] || [];
  const rawSubtitles = rows[headerRowIdx + 1] || [];
  const maxCols = Math.max(rawTitles.length, rawSubtitles.length);
  
  // Fill titles to handle merged category headers (Fila 1)
  const titles: string[] = [];
  let currentTitle = '';
  for (let i = 0; i < maxCols; i++) {
    const t = String(rawTitles[i] || '').trim();
    if (t) currentTitle = t;
    titles.push(currentTitle);
  }

  // Subtitles (Fila 2)
  const subtitles: string[] = [];
  for (let i = 0; i < maxCols; i++) {
    subtitles.push(String(rawSubtitles[i] || '').trim());
  }

  const dataRows = rows.slice(headerRowIdx + 2);
  console.log(`[Mapper] Processing ${dataRows.length} data rows starting from index ${headerRowIdx + 2}`);

  // Pre-calculate identifier column indices to speed up filtering
  const pozoIndices: number[] = [];
  const nickIndices: number[] = [];
  const activoIndices: number[] = [];

  titles.forEach((t, i) => {
    const ut = t.toUpperCase();
    const us = (subtitles[i] || '').toUpperCase();
    if (ut.includes('POZO') || us === 'POZO') pozoIndices.push(i);
    if (ut.includes('NICK') || us === 'NICK') nickIndices.push(i);
    if (ut.includes('ACTIVO') || us === 'ACTIVO') activoIndices.push(i);
  });

  const parseDate = (val: any) => {
    if (!val) return null;
    if (val instanceof Date) return val.toISOString().split('T')[0];
    const s = String(val).trim();
    if (s.toUpperCase() === 'RUNNING' || s === '') return null;
    return s;
  };

  const parseEstado = (val: any): 'NEW' | 'USED' | 'REP' | null => {
    const s = String(val || '').toUpperCase();
    if (s.includes('NEW')) return 'NEW';
    if (s.includes('USED')) return 'USED';
    if (s.includes('REP')) return 'REP';
    return null;
  };

  return dataRows
    .filter((row) => {
      // A row is valid if it has a POZO, NICK, or ACTIVO
      const hasPozo = pozoIndices.some(idx => row[idx] && String(row[idx]).trim() !== '');
      const hasNick = nickIndices.some(idx => row[idx] && String(row[idx]).trim() !== '');
      const hasActivo = activoIndices.some(idx => row[idx] && String(row[idx]).trim() !== '');
      
      return hasPozo || hasNick || hasActivo;
    })
    .map((row, index) => {
      const getVal = (title: string, subtitle?: string) => {
        const sTitle = title.toUpperCase().trim();
        const sSub = subtitle?.toUpperCase().trim();

        for (let i = 0; i < titles.length; i++) {
          const t = titles[i].toUpperCase();
          const s = subtitles[i].toUpperCase();
          const tMatch = t.includes(sTitle);
          
          if (tMatch) {
            if (sSub) {
              const sMatch = s.includes(sSub) || t.includes(sSub);
              if (sMatch) return row[i];
            } else {
              return row[i];
            }
          }
        }
        
        if (!subtitle) {
          for (let i = 0; i < subtitles.length; i++) {
            const s = subtitles[i].toUpperCase();
            if (s === sTitle || s.includes(sTitle)) return row[i];
          }
          for (let i = 0; i < titles.length; i++) {
            const t = titles[i].toUpperCase();
            if (t === sTitle || t.includes(sTitle)) return row[i];
          }
        }
        return undefined;
      };

      const mapComp = (title: string): EquipmentComponent => {
        const getCompVal = (sub: string) => {
          const val = getVal(title, sub);
          return val !== undefined ? String(val).trim() : '';
        };

        return {
          estado: parseEstado(getVal(title, 'ESTADO')) || parseEstado(getVal(title, 'NEW/USED/REP')),
          serie: getCompVal('SERIE') || getCompVal('S/N'),
          etapas: getCompVal('ETAPAS'),
          modelo: getCompVal('MODELO'),
          descripcion: getCompVal('DESCRIPCION'),
          pn: getCompVal('P/N'),
          sn: getCompVal('S/N'),
          hp: getCompVal('HP'),
          vol: getCompVal('VOL.'),
          amp: getCompVal('AMP.'),
          longitud: getCompVal('LONGITUD'),
          awg: getCompVal('AWG'),
          tipo: getCompVal('PLANO/REDONDO'),
          kva: getCompVal('KVA'),
          controlador: getCompVal('CONTROLADOR'),
          ampOut: getCompVal('AMP OUT'),
          pulsos: getCompVal('PULSOS'),
          marca: getCompVal('MARCA'),
          profundidad: getCompVal('PROFUNDIDAD'),
        };
      };

      const rawFechaRun = getVal('FECHA RUN');
      const rawFechaFalla = getVal('FECHA FALLA');
      const rawFechaPull = getVal('FECHA PULL');

      const fechaRun = parseDate(rawFechaRun);
      const fechaFalla = parseDate(rawFechaFalla);
      const fechaPull = parseDate(rawFechaPull);

      const pullVal = String(rawFechaPull || '').toUpperCase().trim();
      const isPulling = rawFechaPull && pullVal !== 'RUNNING' && pullVal !== '';
      const isFailed = fechaFalla && (!rawFechaPull || pullVal === 'RUNNING');
      const isOperativo = !fechaFalla && (!rawFechaPull || pullVal === 'RUNNING');

      let estadoInv: 'OPERATIVO' | 'FALLADO' | 'PULLING' = 'OPERATIVO';
      if (isPulling) estadoInv = 'PULLING';
      else if (isFailed) estadoInv = 'FALLADO';
      else if (isOperativo) estadoInv = 'OPERATIVO';

      const runLifeExcel = Number(getVal('RUN LIFE @ FALLA') || getVal('RUN LIFE @ PULLING') || 0);
      const runLife = runLifeExcel || calculateRunLife(fechaRun || '', fechaFalla || undefined, fechaPull || undefined);

      return {
        excelRowIdx: headerRowIdx + 2 + index, // Actual row index in Excel
        nick: String(getVal('NICK') || ''),
        activo: String(getVal('ACTIVO') || ''),
        bloque: String(getVal('BLOQUE') || ''),
        campo: String(getVal('CAMPO') || ''),
        cluster: String(getVal('CLUSTER') || ''),
        pozo: String(getVal('POZO') || ''),
        runNumber: Number(getVal('# RUN') || 1),
        als: String(getVal('ALS') || 'ESP'),
        proveedor: String(getVal('PROVEEDOR') || ''),
        fechaRun: fechaRun || '',
        fechaFalla: fechaFalla || undefined,
        fechaPull: fechaPull || undefined,
        estadoInventario: estadoInv,
        runLife,
        timestamp: new Date().toISOString(),
        fondo: {
          pumpGasHandled: mapComp('PUMP (GAS HANDLED)'),
          pumpLower: mapComp('PUMP LOWER'),
          pumpCentralA: mapComp('PUMP CENTRAL A'),
          pumpCentralB: mapComp('PUMP CENTRAL B'),
          pumpCentralC: mapComp('PUMP CENTRAL C'),
          pumpCentralD: mapComp('PUMP CENTRAL D'),
          pumpUpper: mapComp('PUMP UPPER'),
          intakeSeparador: mapComp('INTAKE/SEPARADOR DE GAS'),
          protectorSuperior: mapComp('PROTECTOR (SELLO)  SUPERIOR'),
          protectorCentral: mapComp('PROTECTOR (SELLO) CENTRAL'),
          protectorInferior: mapComp('PROTECTOR (SELLO) INFERIOR'),
          motorUT: mapComp('MOTOR UT'),
          motorCT: mapComp('MOTOR CT'),
          motorLT: mapComp('MOTOR LT'),
          tecMotor: String(getVal('TEC.MOTOR') || getVal('AM/PMM') || ''),
          sensor: mapComp('SENSOR'),
          espSummary: String(getVal('ESP', 'RESUMEN') || getVal('ESP') || ''),
        },
        cable: {
          mle: mapComp('MLE'),
          cableFondo: {
            ...mapComp('CABLE (FONDO)'),
            estado2: String(getVal('CABLE (FONDO)', 'ESTADO 2') || getVal('ESTADO 2') || ''),
          },
        },
        superficie: {
          vsd: {
            ...mapComp('VSD'),
            origen: String(getVal('VSD', 'ORIGEN') || getVal('ORIGEN') || ''),
          },
          filter: mapComp('SHIFT/FILTRO ENTRADA'),
          sut: mapComp('SUT'),
        },
        yTool: mapComp('Y-TOOL'),
        detalles: String(getVal('DETALLES/COMENTARIOS') || ''),
      };
    });
};
