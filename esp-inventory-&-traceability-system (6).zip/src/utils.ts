import { differenceInDays, parseISO } from 'date-fns';

export function calculateRunLife(fechaRun: string, fechaFalla?: string, fechaPull?: string): number {
  if (!fechaRun) return 0;
  
  const start = parseISO(fechaRun);
  let end: Date;

  if (fechaFalla) {
    end = parseISO(fechaFalla);
  } else if (fechaPull && fechaPull !== 'RUNNING') {
    end = parseISO(fechaPull);
  } else {
    end = new Date();
  }
  
  const days = differenceInDays(end, start);
  return days > 0 ? days : 0;
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat('es-CO').format(num);
}
